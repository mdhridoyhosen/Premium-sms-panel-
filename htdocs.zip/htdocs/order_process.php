<?php

// ১. এরর রিপোর্টিং এবং হেডার সেটআপ

error_reporting(0);

ini_set('display_errors', 0);

session_start();

header('Content-Type: application/json');

require_once 'db.php';

// ২. অথেনটিফিকেশন চেক

if (!isset($_SESSION['username'])) {

    echo json_encode(['status' => 'error', 'message' => 'Unauthorized! Please login.']);

    exit();

}

$user = $_SESSION['username'];

// ৩. রিকোয়েস্ট মেথড চেক

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    echo json_encode(['status' => 'error', 'message' => 'Invalid Request Method']);

    exit();

}

// ৪. ইনপুট ডাটা প্রসেসিং

$service_id = isset($_POST['service_id']) ? intval($_POST['service_id']) : 0;

$quantity   = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

$input_data_list = [];

foreach ($_POST as $key => $value) {

    if ($key != 'service_id' && $key != 'quantity' && $key != 'total_charge') {

        $field_name = ucwords(str_replace('_', ' ', $key));

        $field_value = mysqli_real_escape_string($conn, $value);

        $input_data_list[] = "$field_name: $field_value";

    }

}

$final_link_data = implode(" | ", $input_data_list);

if (empty($final_link_data)) $final_link_data = "No Data Provided";

// ৫. ভ্যালিডেশন

if ($service_id <= 0 || $quantity <= 0) {

    echo json_encode(['status' => 'error', 'message' => 'Please fill all required fields correctly.']);

    exit();

}

// ৬. সার্ভিস চেক

$s_query = $conn->query("SELECT * FROM services WHERE id = '$service_id' AND status='Active'");

if (!$s_query || $s_query->num_rows == 0) {

    echo json_encode(['status' => 'error', 'message' => 'Service not found or inactive.']);

    exit();

}

$service = $s_query->fetch_assoc();

// ৭. কোয়ান্টিটি লিমিট চেক

if ($quantity < $service['min_qty'] || $quantity > $service['max_qty']) {

    echo json_encode(['status' => 'error', 'message' => "Quantity must be between {$service['min_qty']} and {$service['max_qty']}"]);

    exit();

}

// ৮. প্রাইস ক্যালকুলেশন

$price_per_1k = floatval($service['price']);

$total_charge = ($quantity * $price_per_1k) / 1000;

// ৯. ইউজারের বর্তমান ব্যালেন্স চেক

$u_query = $conn->query("SELECT balance FROM users WHERE username = '$user'");

$userData = $u_query->fetch_assoc();

if ($userData['balance'] < $total_charge) {

    echo json_encode(['status' => 'error', 'message' => 'Insufficient Balance! Please add funds.']);

    exit();

}

// ১০. অর্ডার প্রসেসিং (DATABASE TRANSACTION)

$conn->begin_transaction();

try {

    // A. ব্যালেন্স কাটা এবং টোটাল অর্ডার সংখ্যা বাড়ানো

    // কলামের নাম 'total_order' ব্যবহার করা হয়েছে আপনার চাহিদা অনুযায়ী

    $update_user = $conn->query("UPDATE users SET balance = balance - $total_charge, total_order = total_order + 1 WHERE username = '$user'");

    if (!$update_user) throw new Exception("Failed to update user account.");

    // B. অর্ডার ডাটাবেসে সেভ করা

    $service_name = mysqli_real_escape_string($conn, $service['service_name']);

    $insert_order = $conn->query("INSERT INTO orders (username, service_id, service_name, quantity, charge, link, status, created_at) 

                                  VALUES ('$user', '$service_id', '$service_name', '$quantity', '$total_charge', '$final_link_data', 'Pending', NOW())");

    

    if (!$insert_order) throw new Exception("Order insertion failed.");

    $order_id = $conn->insert_id;

    $conn->commit();

    // ১১. টেলিগ্রাম নোটিফিকেশন (IP BYPASS METHOD)

    sendTelegramNotification($order_id, $user, $service_name, $quantity, $total_charge, $final_link_data);

    echo json_encode(['status' => 'success', 'message' => "Order placed successfully! ID: #{$order_id}"]);

} catch (Exception $e) {

    $conn->rollback();

    echo json_encode(['status' => 'error', 'message' => 'Transaction failed: ' . $e->getMessage()]);

}

// --- টেলিগ্রাম নোটিফিকেশন ফাংশন (IP Bypass) ---

function sendTelegramNotification($order_id, $user, $service_name, $quantity, $total_charge, $final_link_data) {

    $botToken = "8091274126:AAEmZCgDXt1SbH7c4LlTmGa7hXfLuRHURBM";

    $chat_id  = "-1003695936698";

    $msg  = "🔥 *NEW ORDER RECEIVED!*\n\n";

    $msg .= "🆔 *Order ID:* #$order_id\n";

    $msg .= "👤 *User:* $user\n";

    $msg .= "⚙️ *Service:* $service_name\n";

    $msg .= "📦 *Quantity:* $quantity\n";

    $msg .= "💰 *Charge:* $$total_charge\n";

    $msg .= "🔗 *Data:* $final_link_data";

    // IP Bypass Logic

    $telegram_ip = "149.154.167.220"; 

    $url = "https://$telegram_ip/bot$botToken/sendMessage";

    $data = [

        'chat_id'    => $chat_id,

        'text'       => $msg,

        'parse_mode' => 'Markdown'

    ];

    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);

    curl_setopt($ch, CURLOPT_POST, true);

    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    

    // ডোমেইন বাইপাস করার জন্য Host হেডার ব্যবহার

    curl_setopt($ch, CURLOPT_HTTPHEADER, ["Host: api.telegram.org"]);

    

    // SSL ভেরিফিকেশন স্কিপ

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

    

    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);

    curl_setopt($ch, CURLOPT_TIMEOUT, 15);

    $res = curl_exec($ch);

    

    // এরর হলে লগ ফাইলে সেভ হবে

    if (curl_errno($ch)) {

        file_put_contents('tg_debug.txt', date("Y-m-d H:i:s") . " Error: " . curl_error($ch) . "\n", FILE_APPEND);

    }

    

    curl_close($ch);

}

?>