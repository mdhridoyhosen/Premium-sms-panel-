<?php
session_start();
include 'db.php';

// ১. ইউজার লগইন চেক (Security Check)
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$user = $_SESSION['username'];

// ডেমো API Key (আপনার ডাটাবেসে api_key কলাম থাকলে সেখান থেকে আনবেন)
$apiKey = "ftc_" . md5($user) . "_live_v2"; 
$apiUrl = "https://ftcsmm.42web.io/api/v2";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>API Integration - FTC Panel</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Rajdhani:wght@400;500;600;700&family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #00f2ff; /* Neon Cyan */
            --secondary: #7000ff; /* Neon Purple */
            --dark-bg: #0a0a12;
            --card-bg: #13131f;
            --text-color: #e0e0e0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--dark-bg);
            color: var(--text-color);
            overflow-x: hidden;
        }

        /* --- Animations --- */
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes borderFlow { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        @keyframes pulseGlow { 0% { box-shadow: 0 0 5px var(--primary); } 50% { box-shadow: 0 0 20px var(--primary), 0 0 10px var(--secondary); } 100% { box-shadow: 0 0 5px var(--primary); } }
        @keyframes textShine { 0% { background-position: 0% 50%; } 100% { background-position: 100% 50%; } }

        .anim-fade-up { animation: fadeIn 0.8s ease-out forwards; opacity: 0; }
        .delay-1 { animation-delay: 0.2s; }
        .delay-2 { animation-delay: 0.4s; }
        .delay-3 { animation-delay: 0.6s; }

        /* --- Header --- */
        .api-header {
            padding: 40px 0;
            text-align: center;
            background: radial-gradient(circle at center, rgba(112, 0, 255, 0.15) 0%, rgba(10, 10, 18, 0) 70%);
        }

        .gradient-text {
            font-family: 'Rajdhani', sans-serif;
            font-weight: 700;
            font-size: 3rem;
            background: linear-gradient(90deg, #00f2ff, #ffffff, #7000ff);
            background-size: 200% auto;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: textShine 3s linear infinite;
        }

        /* --- Magic Card (Animated Border) --- */
        .magic-card {
            background: var(--card-bg);
            border-radius: 15px;
            padding: 30px;
            position: relative;
            z-index: 1;
            margin-bottom: 30px;
            overflow: hidden;
            transition: transform 0.3s;
        }

        .magic-card::before {
            content: '';
            position: absolute;
            top: -2px; left: -2px; right: -2px; bottom: -2px;
            background: linear-gradient(45deg, var(--primary), var(--secondary), var(--primary));
            background-size: 400%;
            z-index: -1;
            border-radius: 15px;
            animation: borderFlow 10s linear infinite;
            opacity: 0.5;
        }

        .magic-card:hover { transform: translateY(-5px); }
        .magic-card:hover::before { opacity: 1; filter: blur(5px); }

        /* --- API Key Box --- */
        .api-key-box {
            background: rgba(0,0,0,0.3);
            border: 1px solid rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 1.2rem;
            color: var(--primary);
            letter-spacing: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        /* --- Code Block --- */
        pre {
            background: #1e1e2e;
            color: #a9b7c6;
            padding: 20px;
            border-radius: 10px;
            border-left: 5px solid var(--secondary);
            font-size: 0.9rem;
            overflow-x: auto;
            box-shadow: inset 0 0 20px rgba(0,0,0,0.5);
        }
        .code-keyword { color: #cc7832; font-weight: bold; }
        .code-string { color: #6a8759; }
        .code-func { color: #ffc66d; }

        /* --- Buttons --- */
        .btn-neon {
            background: transparent;
            border: 2px solid var(--primary);
            color: var(--primary);
            padding: 10px 30px;
            font-weight: 600;
            border-radius: 50px;
            transition: 0.3s;
            text-transform: uppercase;
            letter-spacing: 1px;
            position: relative;
            overflow: hidden;
        }

        .btn-neon:hover {
            background: var(--primary);
            color: black;
            box-shadow: 0 0 20px var(--primary);
        }

        .btn-dashboard {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 100;
            animation: pulseGlow 2s infinite;
        }

        /* Table Styling */
        .table-dark-custom {
            background: transparent;
            color: #ccc;
        }
        .table-dark-custom th { color: var(--primary); border-bottom: 1px solid rgba(255,255,255,0.1); }
        .table-dark-custom td { border-bottom: 1px solid rgba(255,255,255,0.05); }

    </style>
</head>
<body>


    <div class="container py-4 d-flex justify-content-between align-items-center anim-fade-up">
        <h4 class="fw-bold text-white mb-0"><i class="fas fa-code text-primary"></i> FTC API</h4>
        <a href="dashboard.php" class="btn btn-sm btn-outline-light rounded-pill px-4">
            <i class="fas fa-arrow-left"></i> Back
        </a>
    </div>

    <header class="api-header anim-fade-up">
        <div class="container">
            <h1 class="gradient-text mb-3">API Documentation</h1>
            <p class="text-muted fs-5">Connect your panel with ours using our lightning-fast API.</p>
        </div>
    </header>

    <div class="container pb-5">
        
        <div class="row justify-content-center anim-fade-up delay-1">
            <div class="col-lg-8">
                <div class="magic-card">
                    <h5 class="fw-bold mb-3"><i class="fas fa-key text-warning me-2"></i> Your API Key</h5>
                    <div class="api-key-box">
                        <span id="apiKeyText"><?php echo $apiKey; ?></span>
                        <button class="btn btn-sm btn-outline-secondary border-0 text-white" onclick="copyKey()">
                            <i class="fas fa-copy"></i>
                        </button>
                    </div>
                    <small class="text-muted mt-2 d-block">* Keep this key secret. Do not share it with anyone.</small>
                </div>
            </div>
        </div>

        <div class="row anim-fade-up delay-2">
            <div class="col-md-12">
                <div class="magic-card">
                    <h4 class="fw-bold mb-4 text-white">📡 API Endpoints</h4>
                    <p><strong>API URL:</strong> <code class="text-info"><?php echo $apiUrl; ?></code></p>
                    
                    <div class="table-responsive">
                        <table class="table table-dark-custom">
                            <thead>
                                <tr>
                                    <th>Parameter</th>
                                    <th>Description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td><code class="text-warning">key</code></td><td>Your API Key</td></tr>
                                <tr><td><code class="text-warning">action</code></td><td>Method name (add, status, balance)</td></tr>
                                <tr><td><code class="text-warning">service</code></td><td>Service ID</td></tr>
                                <tr><td><code class="text-warning">link</code></td><td>Link to page/post</td></tr>
                                <tr><td><code class="text-warning">quantity</code></td><td>Quantity needed</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <div class="row anim-fade-up delay-3">
            <div class="col-md-12">
                <div class="magic-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h4 class="fw-bold text-white"><i class="fas fa-code"></i> Example Code (PHP)</h4>
                        <a href="dashboard.php" class="btn btn-sm btn-outline-primary">Go to Dashboard</a>
                    </div>
                    
<pre>
<span class="code-keyword">&lt;?php</span>
<span class="code-string">$api_url</span> = <span class="code-string">'<?php echo $apiUrl; ?>'</span>;
<span class="code-string">$api_key</span> = <span class="code-string">'<?php echo $apiKey; ?>'</span>;

<span class="code-keyword">function</span> <span class="code-func">connect_api</span>(<span class="code-string">$data</span>) {
    <span class="code-keyword">global</span> <span class="code-string">$api_url</span>, <span class="code-string">$api_key</span>;
    <span class="code-string">$data</span>['key'] = <span class="code-string">$api_key</span>;
    
    <span class="code-string">$ch</span> = curl_init();
    curl_setopt(<span class="code-string">$ch</span>, CURLOPT_URL, <span class="code-string">$api_url</span>);
    curl_setopt(<span class="code-string">$ch</span>, CURLOPT_POST, 1);
    curl_setopt(<span class="code-string">$ch</span>, CURLOPT_POSTFIELDS, <span class="code-string">$data</span>);
    curl_setopt(<span class="code-string">$ch</span>, CURLOPT_RETURNTRANSFER, true);
    <span class="code-string">$result</span> = curl_exec(<span class="code-string">$ch</span>);
    curl_close(<span class="code-string">$ch</span>);
    
    <span class="code-keyword">return</span> json_decode(<span class="code-string">$result</span>, true);
}

<span class="code-comment">// Add Order Example</span>
<span class="code-string">$response</span> = <span class="code-func">connect_api</span>([
    'action'   => 'add',
    'service'  => 125,
    'link'     => 'https://example.com/post',
    'quantity' => 1000
]);

print_r(<span class="code-string">$response</span>);
<span class="code-keyword">?&gt;</span>
</pre>
                </div>
            </div>
        </div>

        <div class="text-center mt-4 mb-5 anim-fade-up delay-3">
            <p class="text-muted">Need help integrating?</p>
            <a href="dashboard.php" class="btn btn-neon px-5">
                Contact Support via Dashboard
            </a>
        </div>

    </div>

    <script>
        function copyKey() {
            var copyText = document.getElementById("apiKeyText");
            navigator.clipboard.writeText(copyText.innerText);
            
            // Animation for feedback
            var btn = document.querySelector('.api-key-box button');
            btn.innerHTML = '<i class="fas fa-check text-success"></i>';
            setTimeout(() => { btn.innerHTML = '<i class="fas fa-copy"></i>'; }, 2000);
        }
    </script>

</body>
</html>