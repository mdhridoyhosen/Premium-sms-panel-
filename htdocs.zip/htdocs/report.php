<?php

// ডিবাগিং বন্ধ (লাইভ সাইটের জন্য)

error_reporting(0); 

session_start();

include 'db.php';

// ১. লগইন চেক

if (!isset($_SESSION['username'])) {

    header("Location: index.php");

    exit();

}

$user = $_SESSION['username'];

// নতুন টিকিট আইডি জেনারেট

$ticket_id = "#TKT-" . strtoupper(substr(md5(uniqid(rand(), true)), 0, 5));

// --- ফর্ম সাবমিশন লজিক ---

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    

    // দৈনিক লিমিট চেক

    $today = date('Y-m-d');

    $check_limit = $conn->query("SELECT COUNT(*) as cnt FROM support_tickets WHERE username='$user' AND DATE(created_at)='$today'");

    $limit_row = $check_limit->fetch_assoc();

    

    if ($limit_row['cnt'] >= 10) {

        // লিমিট শেষ হলে রিডাইরেক্ট (এরর সহ)

        header("Location: report.php?status=limit");

        exit();

    } 

    

    // ডাটা রিসিভ

    $t_code = $_POST['t_code'];

    $name = mysqli_real_escape_string($conn, $_POST['name']);

    $contact = mysqli_real_escape_string($conn, $_POST['contact']);

    $message = mysqli_real_escape_string($conn, $_POST['message']);

    if(!empty($message) && !empty($contact)) {

        

        // ডাটাবেসে সেভ

        $stmt = $conn->prepare("INSERT INTO support_tickets (ticket_code, username, full_name, contact_info, message) VALUES (?, ?, ?, ?, ?)");

        $stmt->bind_param("sssss", $t_code, $user, $name, $contact, $message);

        

        if ($stmt->execute()) {

            

            // --- টেলিগ্রাম নোটিফিকেশন (IP Bypass Fix) ---

            $botToken = "8091274126:AAEmZCgDXt1SbH7c4LlTmGa7hXfLuRHURBM";

            $chat_id = "-1003695936698"; 

            $tg_msg = "🆘 **NEW TICKET RECEIVED**\n";

            $tg_msg .= "🆔 ID: `$t_code`\n";

            $tg_msg .= "👤 User: `$user`\n";

            $tg_msg .= "📛 Name: $name\n";

            $tg_msg .= "📞 Contact: `$contact`\n";

            $tg_msg .= "💬 Msg: $message";

            // InfinityFree এর জন্য স্পেশাল বাইপাস

            $telegram_ip = "149.154.167.220";

            $url = "https://$telegram_ip/bot$botToken/sendMessage";

            $data = ['chat_id' => $chat_id, 'text' => $tg_msg, 'parse_mode' => 'Markdown'];

            

            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, $url);

            curl_setopt($ch, CURLOPT_POST, true);

            curl_setopt($ch, CURLOPT_POSTFIELDS, $data);

            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            curl_setopt($ch, CURLOPT_HTTPHEADER, ["Host: api.telegram.org"]);

            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

            $result = curl_exec($ch);

            curl_close($ch);

            // ** রিফ্রেশ ফিক্স (সবচেয়ে গুরুত্বপূর্ণ) **

            // ডাটা সেভ হওয়ার পর পেজ রিডাইরেক্ট করবে, তাই রিফ্রেশ দিলেও আর সাবমিট হবে না

            header("Location: report.php?status=success");

            exit();

        }

    }

}

// টিকিট হিস্ট্রি লোড (লেটেস্ট আগে)

$history = $conn->query("SELECT * FROM support_tickets WHERE username='$user' ORDER BY id DESC");

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Support Center - FTC Panel</title>

    

    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">

    <style>

        :root {

            --primary: #8b5cf6;

            --secondary: #6366f1;

            --dark-bg: #0f172a;

            --glass: rgba(30, 41, 59, 0.7);

            --border: rgba(255, 255, 255, 0.1);

        }

        body {

            font-family: 'Outfit', sans-serif;

            background-color: var(--dark-bg);

            color: #e2e8f0;

            min-height: 100vh;

            background-image: 

                radial-gradient(at 0% 0%, rgba(139, 92, 246, 0.15) 0px, transparent 50%),

                radial-gradient(at 100% 100%, rgba(99, 102, 241, 0.15) 0px, transparent 50%);

            overflow-x: hidden;

        }

        /* Glass Cards */

        .glass-card {

            background: var(--glass);

            backdrop-filter: blur(20px);

            -webkit-backdrop-filter: blur(20px);

            border: 1px solid var(--border);

            border-radius: 20px;

            padding: 30px;

            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.3);

            height: 100%;

            transition: 0.3s;

        }

        /* Floating Input Styles */

        .form-floating > .form-control {

            background: rgba(255, 255, 255, 0.05);

            border: 1px solid var(--border);

            color: white;

            border-radius: 12px;

        }

        .form-floating > .form-control:focus {

            background: rgba(255, 255, 255, 0.1);

            border-color: var(--primary);

            box-shadow: 0 0 15px rgba(139, 92, 246, 0.2);

            color: white;

        }

        .form-floating > label { color: #94a3b8; }

        /* Submit Button */

        .btn-gradient {

            background: linear-gradient(135deg, var(--primary), var(--secondary));

            border: none;

            color: white;

            padding: 12px;

            border-radius: 12px;

            font-weight: 600;

            width: 100%;

            letter-spacing: 0.5px;

            transition: 0.3s;

            box-shadow: 0 4px 15px rgba(139, 92, 246, 0.3);

        }

        .btn-gradient:hover {

            transform: translateY(-2px);

            box-shadow: 0 8px 25px rgba(139, 92, 246, 0.5);

        }

        /* Ticket History Items */

        .ticket-item {

            background: rgba(255, 255, 255, 0.03);

            border: 1px solid var(--border);

            border-radius: 16px;

            padding: 20px;

            margin-bottom: 20px;

            position: relative;

            transition: 0.3s;

        }

        .ticket-item:hover { background: rgba(255, 255, 255, 0.06); transform: translateX(5px); }

        .ticket-header {

            display: flex;

            justify-content: space-between;

            align-items: center;

            margin-bottom: 10px;

            border-bottom: 1px dashed var(--border);

            padding-bottom: 10px;

        }

        /* Chat Bubble Style for Admin Reply */

        .admin-reply-box {

            background: rgba(16, 185, 129, 0.1);

            border-left: 4px solid #10b981;

            padding: 15px;

            border-radius: 0 12px 12px 0;

            margin-top: 15px;

            font-size: 0.95rem;

            color: #d1fae5;

            position: relative;

            animation: fadeIn 0.5s ease;

        }

        

        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        .status-badge {

            font-size: 11px;

            padding: 5px 12px;

            border-radius: 50px;

            font-weight: 700;

            text-transform: uppercase;

        }

        .status-pending { background: rgba(251, 191, 36, 0.2); color: #fbbf24; border: 1px solid rgba(251, 191, 36, 0.3); }

        .status-replied { background: rgba(52, 211, 153, 0.2); color: #34d399; border: 1px solid rgba(52, 211, 153, 0.3); }

        /* Custom Scrollbar */

        .scroll-area { max-height: 600px; overflow-y: auto; padding-right: 10px; }

        ::-webkit-scrollbar { width: 6px; }

        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.2); border-radius: 10px; }

    </style>

</head>

<body>

    <div class="container py-5">

        

        <div class="d-flex justify-content-between align-items-center mb-5">

            <div>

                <h2 class="fw-bold mb-0 text-white"><i class="fas fa-headset me-2 text-primary"></i> Help Desk</h2>

                <small class="text-muted">We usually reply within 1 hour</small>

            </div>

            <a href="dashboard.php" class="btn btn-outline-light btn-sm rounded-pill px-4">

                <i class="fas fa-arrow-left me-2"></i> Dashboard

            </a>

        </div>

        <div class="row g-4">

            

            <div class="col-lg-5">

                <div class="glass-card">

                    <div class="d-flex align-items-center mb-4">

                        <div class="bg-primary bg-opacity-25 p-3 rounded-circle text-primary me-3">

                            <i class="fas fa-edit fa-lg"></i>

                        </div>

                        <h5 class="fw-bold mb-0 text-white">Create Ticket</h5>

                    </div>

                    

                    <form method="POST">

                        

                        <div class="form-floating mb-3">

                            <input type="text" class="form-control fw-bold text-info" name="t_code" value="<?php echo $ticket_id; ?>" readonly>

                            <label>Ticket ID (Auto)</label>

                        </div>

                        <div class="form-floating mb-3">

                            <input type="text" class="form-control" name="name" placeholder="Name" required>

                            <label>Your Name</label>

                        </div>

                        <div class="form-floating mb-3">

                            <input type="text" class="form-control" name="contact" placeholder="Contact" required>

                            <label>Email / WhatsApp / Telegram</label>

                        </div>

                        <div class="form-floating mb-4">

                            <textarea class="form-control" name="message" placeholder="Msg" style="height: 130px" required></textarea>

                            <label>Describe your issue...</label>

                        </div>

                        <button type="submit" class="btn-gradient">

                            Submit Ticket <i class="fas fa-paper-plane ms-2"></i>

                        </button>

                    </form>

                </div>

            </div>

            <div class="col-lg-7">

                <div class="glass-card">

                    <div class="d-flex justify-content-between align-items-center mb-4 border-bottom border-secondary pb-3">

                        <h5 class="fw-bold mb-0 text-white"><i class="fas fa-history me-2 text-info"></i> Your Tickets</h5>

                        <span class="badge bg-dark border border-secondary"><?php echo $history->num_rows; ?> Total</span>

                    </div>

                    <div class="scroll-area">

                        <?php if($history && $history->num_rows > 0): ?>

                            <?php while($row = $history->fetch_assoc()): ?>

                                

                                <div class="ticket-item">

                                    <div class="ticket-header">

                                        <div>

                                            <span class="text-primary fw-bold me-2"><?php echo $row['ticket_code']; ?></span>

                                            <span class="text-muted" style="font-size: 11px;">

                                                <i class="far fa-clock"></i> <?php echo date("d M, h:i A", strtotime($row['created_at'])); ?>

                                            </span>

                                        </div>

                                        <div>

                                            <?php if(!empty($row['admin_reply'])): ?>

                                                <span class=" status-badge status-replied"><i class="fas fa-check-circle me-1"></i></span>

                                            <?php else: ?>

                                                <span class="status-badge status-pending"><i class="fas fa-spinner me-1"></i></span>

                                            <?php endif; ?>

                                        </div>

                                    </div>

                                    <p class="mb-0 text-white-50" style="font-size: 0.95rem; line-height: 1.6;">

                                        <?php echo htmlspecialchars($row['message']); ?>

                                    </p>

                                    <?php if(!empty($row['admin_reply'])): ?>

                                        <div class="admin-reply-box">

                                            <div class="d-flex align-items-center mb-2">

                                                <img src="https://cdn-icons-png.flaticon.com/512/4440/4440467.png" width="24" height="24" class="me-2 rounded-circle">

                                                <strong class="text-success">Admin Support</strong>

                                            </div>

                                            <?php echo htmlspecialchars($row['admin_reply']); ?>

                                        </div>

                                    <?php endif; ?>

                                </div>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <div class="text-center py-5">

                                <i class="fas fa-inbox fa-3x text-muted mb-3 opacity-25"></i>

                                <h6 class="text-muted">No tickets found yet.</h6>

                            </div>

                        <?php endif; ?>

                    </div>

                </div>

            </div>

        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>

        // URL Parameter Check for Success/Error

        const urlParams = new URLSearchParams(window.location.search);

        

        if (urlParams.get('status') === 'success') {

            Swal.fire({

                icon: 'success',

                title: 'Ticket Submitted!',

                text: 'We have received your request. Admin will reply shortly.',

                background: '#1e293b',

                color: '#fff',

                confirmButtonColor: '#8b5cf6'

            }).then(() => {

                // Remove param from URL without refresh

                window.history.replaceState(null, null, window.location.pathname);

            });

        }

        

        if (urlParams.get('status') === 'limit') {

            Swal.fire({

                icon: 'error',

                title: 'Limit Reached',

                text: 'You have reached the daily limit of 5 tickets.',

                background: '#1e293b',

                color: '#fff',

                confirmButtonColor: '#ef4444'

            });

        }

    </script>

</body>

</html>