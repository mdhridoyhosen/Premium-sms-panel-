<?php

session_start();

include 'db.php';

// ১. এডমিন লগইন (পিন: 1122)

if (isset($_POST['login'])) {

    if ($_POST['pass'] === '1122') $_SESSION['admin'] = true;

}

if (isset($_GET['logout'])) { session_destroy(); header("Location: admin_orders.php"); }

// লগইন পেজ ডিজাইন

if (!isset($_SESSION['admin'])) {

    echo '<!DOCTYPE html>

    <html lang="en">

    <head>

        <meta charset="UTF-8">

        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Admin Login</title>

        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

        <style>body{background:#1e1e2d;height:100vh;display:flex;align-items:center;justify-content:center;}</style>

    </head>

    <body>

        <div class="card p-4 shadow-lg" style="width:350px;">

            <h4 class="text-center mb-3">Admin Panel</h4>

            <form method="POST">

                <input type="password" name="pass" class="form-control mb-3" placeholder="Enter PIN (1122)" required>

                <button type="submit" name="login" class="btn btn-primary w-100">Login</button>

            </form>

        </div>

    </body>

    </html>';

    exit();

}

// ২. অর্ডার অ্যাকশন (Complete / Refund)

if (isset($_POST['action'])) {

    $oid = intval($_POST['oid']);

    $act = $_POST['action'];

    $res = $conn->query("SELECT * FROM orders WHERE id='$oid'");

    $order = $res->fetch_assoc();

    if ($order && ($order['status'] == 'Pending' || $order['status'] == 'In Progress')) {

        $user = $order['username'];

        $service_name = mysqli_real_escape_string($conn, $order['service_name']);

        if ($act == 'complete') {

            // Update Order Status

            $conn->query("UPDATE orders SET status='Completed' WHERE id='$oid'");

            

            // 🔥 Update User Notification (English)

            $msg = "✅ Your order #$oid ($service_name) has been accepted and completed.";

            $conn->query("UPDATE users SET notification_update = '$msg' WHERE username='$user'");

            echo "<script>alert('✅ Order #$oid marked as Completed!');</script>";

        } 

        elseif ($act == 'cancel') {

            $charge = $order['charge'];

            

            // Refund Balance

            $conn->query("UPDATE users SET balance = balance + $charge WHERE username='$user'");

            // Update Order Status

            $conn->query("UPDATE orders SET status='Canceled' WHERE id='$oid'");

            

            // 🔥 Update User Notification (English)

            $msg = "⚠️ Your order #$oid has been canceled and $$charge has been refunded to your balance.";

            $conn->query("UPDATE users SET notification_update = '$msg' WHERE username='$user'");

            

            echo "<script>alert('⚠️ Order Canceled! $$charge refunded to $user.');</script>";

        }

    }

}

// ৩. অর্ডার লিস্ট আনা

$orders = $conn->query("SELECT * FROM orders ORDER BY id DESC");

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Order Manager | Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>

        body { background: #f4f6f9; font-family: 'Segoe UI', sans-serif; }

        .badge-pending { background: #ffc107; color: #000; }

        .badge-completed { background: #198754; color: #fff; }

        .badge-canceled { background: #dc3545; color: #fff; }

        .data-truncate { max-width: 150px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        .modal-header { background: #1e1e2d; color: #fff; }

        .detail-row { border-bottom: 1px solid #eee; padding: 10px 0; }

        .detail-label { font-weight: bold; color: #555; width: 120px; display: inline-block; }

        .full-data-box { background: #f8f9fa; padding: 15px; border-radius: 5px; border: 1px solid #ddd; font-family: monospace; color: #d63384; }

    </style>

</head>

<body>

<nav class="navbar navbar-dark bg-dark px-4 shadow-sm">

    <span class="navbar-brand fw-bold"><i class="fas fa-shield-alt me-2"></i>Admin Order Panel</span>

    <a href="?logout=true" class="btn btn-outline-danger btn-sm">Logout</a>

</nav>

<div class="container-fluid py-4">

    <div class="card shadow">

        <div class="card-header bg-white py-3">

            <h5 class="m-0 fw-bold text-primary">All Orders List</h5>

        </div>

        <div class="card-body table-responsive p-0">

            <table class="table table-hover align-middle mb-0">

                <thead class="table-light">

                    <tr>

                        <th>#ID</th>

                        <th>User</th>

                        <th>Service</th>

                        <th>Input Data (Preview)</th>

                        <th>Charge</th>

                        <th>Status</th>

                        <th class="text-end">Actions</th>

                    </tr>

                </thead>

                <tbody>

                    <?php while($row = $orders->fetch_assoc()): 

                        $st = $row['status'];

                        $badge = 'badge-pending';

                        if($st=='Completed') $badge='badge-completed';

                        if($st=='Canceled') $badge='badge-canceled';

                        $full_data_formatted = str_replace(" | ", "<br>", htmlspecialchars($row['link']));

                    ?>

                    <tr>

                        <td>#<?php echo $row['id']; ?></td>

                        <td class="fw-bold"><?php echo $row['username']; ?></td>

                        <td><small class="text-muted"><?php echo substr($row['service_name'], 0, 30); ?>...</small></td>

                        <td class="data-truncate" style="max-width: 200px;">

                            <small><?php echo htmlspecialchars($row['link']); ?></small>

                        </td>

                        <td class="fw-bold text-success">$<?php echo $row['charge']; ?></td>

                        <td><span class="badge <?php echo $badge; ?>"><?php echo $st; ?></span></td>

                        <td class="text-end">

                            <button class="btn btn-info btn-sm text-white view-btn" 

                                data-id="<?php echo $row['id']; ?>"

                                data-user="<?php echo $row['username']; ?>"

                                data-service="<?php echo htmlspecialchars($row['service_name']); ?>"

                                data-qty="<?php echo $row['quantity']; ?>"

                                data-charge="<?php echo $row['charge']; ?>"

                                data-status="<?php echo $st; ?>"

                                data-date="<?php echo $row['created_at']; ?>"

                                data-full-content="<?php echo $full_data_formatted; ?>"

                            >

                                <i class="fas fa-eye"></i> View

                            </button>

                            <?php if($st == 'Pending'): ?>

                            <form method="POST" style="display:inline-block;" onsubmit="return confirm('Complete this order?');">

                                <input type="hidden" name="oid" value="<?php echo $row['id']; ?>">

                                <input type="hidden" name="action" value="complete">

                                <button class="btn btn-success btn-sm"><i class="fas fa-check"></i></button>

                            </form>

                            <form method="POST" style="display:inline-block;" onsubmit="return confirm('Refund & Cancel?');">

                                <input type="hidden" name="oid" value="<?php echo $row['id']; ?>">

                                <input type="hidden" name="action" value="cancel">

                                <button class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button>

                            </form>

                            <?php endif; ?>

                        </td>

                    </tr>

                    <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<div class="modal fade" id="orderModal" tabindex="-1">

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">Order Details <span id="modalOrderId"></span></h5>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>

            </div>

            <div class="modal-body">

                <div class="detail-row"><span class="detail-label">User:</span> <span id="modalUser" class="fw-bold"></span></div>

                <div class="detail-row"><span class="detail-label">Service:</span> <span id="modalService"></span></div>

                <div class="detail-row"><span class="detail-label">Quantity:</span> <span id="modalQty"></span></div>

                <div class="detail-row"><span class="detail-label">Cost:</span> <span class="text-success fw-bold">$<span id="modalCharge"></span></span></div>

                <div class="detail-row"><span class="detail-label">Date:</span> <span id="modalDate" class="small text-muted"></span></div>

                <div class="detail-row"><span class="detail-label">Status:</span> <span id="modalStatus" class="badge bg-secondary"></span></div>

                <h6 class="mt-4 fw-bold text-dark border-bottom pb-2">User Inputs (Full Data):</h6>

                <div class="full-data-box" id="modalData"></div>

            </div>

            <div class="modal-footer">

                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>

    const orderModal = new bootstrap.Modal(document.getElementById('orderModal'));

    document.querySelectorAll('.view-btn').forEach(button => {

        button.addEventListener('click', function() {

            const id = this.getAttribute('data-id');

            const user = this.getAttribute('data-user');

            const service = this.getAttribute('data-service');

            const qty = this.getAttribute('data-qty');

            const charge = this.getAttribute('data-charge');

            const status = this.getAttribute('data-status');

            const date = this.getAttribute('data-date');

            const content = this.getAttribute('data-full-content');

            document.getElementById('modalOrderId').innerText = '#' + id;

            document.getElementById('modalUser').innerText = user;

            document.getElementById('modalService').innerText = service;

            document.getElementById('modalQty').innerText = qty;

            document.getElementById('modalCharge').innerText = charge;

            document.getElementById('modalStatus').innerText = status;

            document.getElementById('modalDate').innerText = date;

            document.getElementById('modalData').innerHTML = content;

            orderModal.show();

        });

    });

</script>

</body>

</html>