<?php

session_start();

include 'db.php';

// --- অ্যাডমিন লগইন চেক ---

if (isset($_POST['login'])) {

    if ($_POST['pass'] === '1122') {

        $_SESSION['admin_access'] = true;

    } else {

        $error = "ভুল পাসওয়ার্ড!";

    }

}

if (isset($_GET['logout'])) {

    session_destroy();

    header("Location: report_admin.php");

    exit();

}

if (!isset($_SESSION['admin_access'])) {

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Admin Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>body{background:#1e293b;height:100vh;display:flex;align-items:center;justify-content:center;}</style>

</head>

<body>

    <div class="card p-4 text-white" style="width:350px; background: #0f172a; border: 1px solid #334155;">

        <h4 class="text-center mb-3">Support Admin</h4>

        <?php if(isset($error)) echo "<div class='alert alert-danger py-1'>$error</div>"; ?>

        <form method="POST">

            <input type="password" name="pass" class="form-control mb-3" placeholder="PIN ()" required>

            <button type="submit" name="login" class="btn btn-primary w-100">Login</button>

        </form>

    </div>

</body>

</html>

<?php exit(); } 

// --- রিপ্লাই লজিক ---

if (isset($_POST['send_reply'])) {

    $id = $_POST['ticket_id'];

    $reply = mysqli_real_escape_string($conn, $_POST['reply_msg']);

    

    // ডাটাবেসে রিপ্লাই আপডেট করা

    $conn->query("UPDATE support_tickets SET admin_reply='$reply', status='Replied' WHERE id='$id'");

    $success_msg = "Reply sent successfully!";

}

// সব টিকিট লোড করা (নতুনগুলো আগে)

$tickets = $conn->query("SELECT * FROM support_tickets ORDER BY id DESC");

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Admin Dashboard - Tickets</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>

        body { background: #f1f5f9; font-family: sans-serif; }

        .ticket-card { background: white; border-radius: 12px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); border-left: 5px solid #6366f1; }

        .ticket-replied { border-left-color: #10b981; background: #f0fdf4; }

        .user-info { font-size: 13px; color: #64748b; background: #f8fafc; padding: 10px; border-radius: 8px; }

    </style>

</head>

<body class="p-4">

<div class="container">

    <div class="d-flex justify-content-between align-items-center mb-4">

        <h3 class="fw-bold text-dark"><i class="fas fa-user-shield text-primary"></i> Ticket Manager</h3>

        <a href="?logout=true" class="btn btn-danger btn-sm">Logout</a>

    </div>

    <?php if(isset($success_msg)) echo "<div class='alert alert-success'>$success_msg</div>"; ?>

    <div class="row">

        <?php while($row = $tickets->fetch_assoc()): ?>

            <div class="col-12">

                <div class="ticket-card <?php echo !empty($row['admin_reply']) ? 'ticket-replied' : ''; ?>">

                    

                    <div class="d-flex justify-content-between align-items-start">

                        <div>

                            <span class="badge bg-dark mb-2"><?php echo $row['ticket_code']; ?></span>

                            <h5 class="fw-bold text-dark mb-1"><?php echo htmlspecialchars($row['message']); ?></h5>

                        </div>

                        <span class="badge <?php echo !empty($row['admin_reply']) ? 'bg-success' : 'bg-warning text-dark'; ?>">

                            <?php echo !empty($row['admin_reply']) ? 'Replied' : 'Pending'; ?>

                        </span>

                    </div>

                    <div class="row mt-3">

                        <div class="col-md-4">

                            <div class="user-info">

                                <strong>User:</strong> <?php echo $row['username']; ?><br>

                                <strong>Name:</strong> <?php echo $row['full_name']; ?><br>

                                <strong>Contact:</strong> <?php echo $row['contact_info']; ?><br>

                                <small><?php echo $row['created_at']; ?></small>

                            </div>

                        </div>

                        

                        <div class="col-md-8">

                            <form method="POST">

                                <input type="hidden" name="ticket_id" value="<?php echo $row['id']; ?>">

                                <label class="fw-bold small text-secondary">Admin Response:</label>

                                <div class="input-group">

                                    <textarea name="reply_msg" class="form-control" rows="2" placeholder="Write a reply..." required><?php echo $row['admin_reply']; ?></textarea>

                                    <button type="submit" name="send_reply" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>

                                </div>

                            </form>

                        </div>

                    </div>

                </div>

            </div>

        <?php endwhile; ?>

    </div>

</div>

</body>

</html>