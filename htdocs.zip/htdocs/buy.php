<?php

session_start();

include 'db.php';

if (!isset($_SESSION['username'])) { header("Location: index.php"); exit(); }

$user = $_SESSION['username'];

$u_res = $conn->query("SELECT * FROM users WHERE username='$user'");

$userData = $u_res->fetch_assoc();

$platforms = [];

$p_res = $conn->query("SELECT * FROM platforms WHERE status='Active'");

while($row = $p_res->fetch_assoc()) { $platforms[] = $row; }

$services = [];

$s_res = $conn->query("SELECT * FROM services WHERE status='Active'");

while($row = $s_res->fetch_assoc()) { $services[] = $row; }

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>New Order | FTC Panel</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">

    

    <style>

        body { background: #f1f5f9; font-family: 'Segoe UI', sans-serif; font-size: 14px; padding-top: 15px; }

        

        .main-content { width: 100%; max-width: 1400px; margin: 0 auto; padding: 0 12px; }

        /* হেডার সেকশন ছোট করা হয়েছে */

        .top-user-info { 

            background: #1e1e2d; color: white; padding: 10px 15px; 

            border-radius: 8px; margin-bottom: 20px; 

            display: flex; justify-content: space-between; align-items: center;

            font-size: 13px;

        }

        /* গ্রিড লেআউট: মোবাইলে সবসময় ২টি, ডেক্সটপে জায়গা অনুযায়ী বাড়বে */

        .p-grid { 

            display: grid; 

            grid-template-columns: repeat(2, 1fr); /* ডিফল্ট ২টি করে */

            gap: 10px; 

            margin-bottom: 25px; 

        }

        /* ডেক্সটপ বা বড় স্ক্রিনের জন্য গ্রিড পরিবর্তন */

        @media (min-width: 768px) {

            .p-grid { grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); }

        }

        .p-card {

            background: #125E67 !important;

            color: white !important;

            border-radius: 8px;

            cursor: pointer;

            border: 1.5px solid transparent;

            transition: all 0.2s ease;

            display: flex !important;

            align-items: center !important;

            justify-content: flex-start !important;

            height: 48px !important;

            padding: 0 10px !important;

            gap: 8px;

        }

        .p-card:hover, .p-card.active { 

            border-color: #4f46e5; 

            background: #eef2ff !important; 

            color: #4f46e5 !important;

        }

        .p-img { width: 24px !important; height: 24px !important; object-fit: cover; border-radius: 50% !important; }

        .p-name { font-size: 11px !important; font-weight: 600 !important; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

        /* অর্ডার কার্ড */

        .order-card { 

            background: #fff; padding: 20px; border-radius: 12px; 

            box-shadow: 0 5px 15px rgba(0,0,0,0.05); 

            max-width: 800px; margin: 0 auto;

        }

        .info-badges { display: flex; gap: 8px; margin: 15px 0; display: none; }

        .badge-item { background: #f8fafc; padding: 6px; border-radius: 6px; font-size: 11px; font-weight: 600; border: 1px solid #e2e8f0; flex: 1; text-align: center; }

        .charge-box { background: #1e1e2d; color: #fff; padding: 15px; border-radius: 10px; margin-top: 15px; display: flex; justify-content: space-between; align-items: center; }

        .charge-box h3 { font-size: 18px; margin: 0; }

        

        .btn-submit { background: #4f46e5; color: white; border: none; padding: 12px; width: 100%; border-radius: 8px; font-size: 15px; font-weight: bold; margin-top: 15px; }

        /* ইনপুট ফিল্ড ছোট করা */

        .form-control, .form-select { padding: 8px 12px; font-size: 13px; border-radius: 6px; }

        label { font-size: 13px; margin-bottom: 5px; }

        @media (max-width: 576px) {

            .top-user-info { flex-direction: column; gap: 5px; text-align: center; }

        }

    </style>

</head>

<body>

<div class="main-content">

    <div class="top-user-info">

        <span class="fw-bold"><i class="fas fa-user-circle me-1"></i> <?php echo $user; ?></span>

        <span class="text-warning fw-bold"><i class="fas fa-wallet me-1"></i> $<?php echo number_format($userData['balance'], 4); ?></span>

    </div>

    <div class="p-grid">

        <?php foreach($platforms as $p): ?>

        <div class="p-card" onclick="loadServices(<?php echo $p['id']; ?>, this)">

            <img src="<?php echo !empty($p['icon_url']) ? $p['icon_url'] : 'img/default.png'; ?>" class="p-img">

            <div class="p-name"><?php echo $p['name']; ?></div>

        </div>

        <?php endforeach; ?>

    </div>

    <div class="order-card">

        <form id="orderForm">

            <div class="mb-3">

                <label class="fw-bold text-secondary">Service Category</label>

                <select class="form-select" id="serviceSelect" name="service_id" disabled required>

                    <option value="">Choose Platform</option>

                </select>

            </div>

            <div class="info-badges" id="serviceInfo">

                <div class="badge-item">Rate: $<span id="viewPrice">0</span></div>

                <div class="badge-item">Min: <span id="viewMin">0</span></div>

                <div class="badge-item">Max: <span id="viewMax">0</span></div>

            </div>

            <div id="dynamicInputs"></div>

            <div class="mb-3">

                <label class="fw-bold text-secondary">Quantity</label>

                <input type="number" name="quantity" id="qty" class="form-control" placeholder="0" disabled required>

                <div id="qtyError" class="text-danger x-small mt-1" style="display:none; font-size: 11px;"></div>

            </div>

            <div class="charge-box">

                <div>

                    <small class="opacity-75">Total Charge</small>

                    <h3>$<span id="displayTotal">0.0000</span></h3>

                </div>

                <i class="fas fa-receipt fa-2x opacity-25"></i>

            </div>

            <button type="submit" class="btn-submit" id="submitBtn" disabled>PLACE ORDER</button>

        </form>

    </div>

</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

    const services = <?php echo json_encode($services); ?>;

    let currentSvc = null;

    function loadServices(pid, el) {

        $('.p-card').removeClass('active'); 

        $(el).addClass('active');

        const filtered = services.filter(s => s.platform_id == pid);

        const select = $('#serviceSelect');

        select.empty().append('<option value="">-- Select Service --</option>');

        filtered.forEach(s => select.append(`<option value="${s.id}">${s.service_name}</option>`));

        select.prop('disabled', false);

        $('#serviceInfo').hide(); $('#dynamicInputs').empty(); $('#qty').val('').prop('disabled', true);

        $('#displayTotal').text('0.0000');

    }

    $('#serviceSelect').change(function(){

        const sid = $(this).val();

        currentSvc = services.find(s => s.id == sid);

        const box = $('#dynamicInputs'); box.empty();

        if(currentSvc) {

            $('#viewPrice').text(currentSvc.price); 

            $('#viewMin').text(currentSvc.min_qty); 

            $('#viewMax').text(currentSvc.max_qty);

            $('#serviceInfo').css('display', 'flex');

            try {

                JSON.parse(currentSvc.input_config).forEach(f => {

                    let name = f.label.replace(/ /g, "_").toLowerCase();

                    box.append(`<div class="mb-3"><label class="fw-bold text-secondary">${f.label}</label><input type="${f.type}" name="${name}" class="form-control" required></div>`);

                });

            } catch(e) {}

            $('#qty').prop('disabled', false);

        }

    });

    $('#qty').on('input', function(){

        if(!currentSvc) return;

        let q = parseFloat($(this).val());

        let total = ((q * parseFloat(currentSvc.price)) / 1000).toFixed(4);

        if(q < currentSvc.min_qty || q > currentSvc.max_qty) {

            $('#qtyError').text(`Limit: ${currentSvc.min_qty} - ${currentSvc.max_qty}`).show();

            $('#submitBtn').prop('disabled', true);

        } else {

            $('#qtyError').hide();

            $('#submitBtn').prop('disabled', false);

        }

        $('#displayTotal').text(isNaN(total) ? '0.0000' : total);

    });

    $('#orderForm').on('submit', function(e){

        e.preventDefault();

        let btn = $('#submitBtn');

        btn.html('Processing...').prop('disabled', true);

        $.ajax({

            url: 'order_process.php',

            type: 'POST',

            data: new FormData(this),

            contentType: false, processData: false,

            success: function(res) {

                btn.html('PLACE ORDER').prop('disabled', false);

                if(res.status === 'success') {

                    Swal.fire({ icon: 'success', title: 'Success', text: res.message, timer: 2000 }).then(() => location.reload());

                } else {

                    Swal.fire('Error', res.message, 'error');

                }

            }

        });

    });

</script>

</body>

</html>