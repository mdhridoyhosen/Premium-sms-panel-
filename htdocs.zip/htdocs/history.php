<?php

// ডিবাগিং অন করা (যাতে এরর দেখা যায়)

ini_set('display_errors', 1);

ini_set('display_startup_errors', 1);

error_reporting(E_ALL);

session_start();

include 'db.php';

// লগইন চেক

if (!isset($_SESSION['username'])) { header("Location: index.php"); exit(); }

$user = $_SESSION['username'];

// ডিলিট লজিক

if (isset($_GET['delete_id'])) {

    $del_id = intval($_GET['delete_id']);

    $check = $conn->query("SELECT * FROM orders WHERE id='$del_id' AND username='$user'");

    if ($check->num_rows > 0) {

        $conn->query("DELETE FROM orders WHERE id='$del_id'");

        header("Location: history.php?msg=deleted");

        exit();

    }

}

// অর্ডার ফেচ করা

$orders = $conn->query("SELECT * FROM orders WHERE username='$user' ORDER BY id DESC");

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>History | FTC Panel</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">

    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>

        :root {

            --primary: #4f46e5;

            --bg-body: #f8fafc;

            --text-main: #334155;

            --sidebar-width: 260px;

        }

        body { font-family: 'Inter', sans-serif; background: var(--bg-body); color: var(--text-main); font-size: 13px; overflow-x: hidden; }

        /* Sidebar */

        .sidebar { width: var(--sidebar-width); height: 100vh; position: fixed; top: 0; left: 0; background: #0f172a; color: #fff; z-index: 1000; }

        .main-content { margin-left: var(--sidebar-width); padding: 20px; transition: 0.3s; }

        /* Compact Card */

        .card-box {

            background: #fff; border-radius: 12px;

            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);

            border: 1px solid #e2e8f0; overflow: hidden;

        }

        .card-header-custom {

            padding: 15px 20px; border-bottom: 1px solid #f1f5f9;

            display: flex; justify-content: space-between; align-items: center; background: #fff;

        }

        /* Compact Table */

        .table-responsive { overflow-x: auto; -webkit-overflow-scrolling: touch; }

        .table-custom { width: 100%; border-collapse: collapse; white-space: nowrap; }

        

        .table-custom th {

            background: #f8fafc; color: #64748b; font-weight: 600;

            text-transform: uppercase; font-size: 11px; letter-spacing: 0.5px;

            padding: 12px 15px; border-bottom: 1px solid #e2e8f0;

        }

        

        .table-custom td {

            padding: 10px 15px; vertical-align: middle;

            border-bottom: 1px solid #f1f5f9; font-size: 13px;

        }

        

        /* Service Name Truncate */

        .service-name {

            max-width: 200px; overflow: hidden; text-overflow: ellipsis; display: block;

            font-weight: 600; color: #1e293b;

        }

        /* Badges */

        .badge-status { padding: 4px 8px; border-radius: 6px; font-weight: 600; font-size: 10px; display: inline-flex; align-items: center; gap: 4px; }

        .st-pending { background: #fff7ed; color: #c2410c; border: 1px solid #ffedd5; }

        .st-success { background: #f0fdf4; color: #15803d; border: 1px solid #dcfce7; }

        .st-cancel { background: #fef2f2; color: #b91c1c; border: 1px solid #fee2e2; }

        .st-process { background: #eff6ff; color: #1d4ed8; border: 1px solid #dbeafe; }

        /* Action Buttons */

        .btn-icon {

            width: 28px; height: 28px; border-radius: 6px; border: none;

            display: inline-flex; align-items: center; justify-content: center;

            transition: 0.2s; cursor: pointer; font-size: 12px;

        }

        .btn-view { background: #e0e7ff; color: #4f46e5; }

        .btn-view:hover { background: #4f46e5; color: #fff; }

        .btn-del { background: #fee2e2; color: #ef4444; margin-left: 5px; }

        .btn-del:hover { background: #ef4444; color: #fff; }

        /* Modal Styling */

        .modal-content { border-radius: 12px; border: none; font-size: 13px; }

        .modal-header { background: #0f172a; color: #fff; padding: 15px 20px; border-radius: 12px 12px 0 0; }

        .detail-row { display: flex; justify-content: space-between; border-bottom: 1px solid #f1f5f9; padding: 10px 0; }

        .detail-label { color: #64748b; font-weight: 500; }

        .detail-val { font-weight: 600; color: #1e293b; text-align: right; }

        .data-box { background: #f8fafc; padding: 10px; border-radius: 8px; border: 1px solid #e2e8f0; font-family: monospace; font-size: 12px; color: #334155; margin-top: 5px; word-break: break-all; }

        @media (max-width: 768px) {

            .sidebar { left: -260px; }

            .main-content { margin-left: 0; padding: 15px; }

            .service-name { max-width: 140px; } 

        }

    </style>

</head>

<body>

<div class="sidebar p-3">

    <h4 class="text-white mb-4">FTC Panel</h4>

    <small class="text-secondary">Logged as: <?php echo $user; ?></small>

</div>

<div class="main-content">

    <div class="container-fluid p-0">

        

        <div class="d-flex justify-content-between align-items-center mb-3" data-aos="fade-down">

            <div>

                <h5 class="fw-bold m-0 text-dark">Order History</h5>

                <small class="text-muted">Track your services</small>

            </div>

            <a href="buy.php" class="btn btn-primary btn-sm rounded-pill px-3 shadow-sm" style="font-size: 12px;">

                <i class="fas fa-plus me-1"></i> New Order

            </a>

        </div>

        <div class="card-box" data-aos="fade-up">

            <div class="card-header-custom">

                <small class="fw-bold text-dark"><i class="fas fa-list me-2 text-primary"></i>Recent Transactions</small>

                <span class="badge bg-light text-dark border"><?php echo $orders->num_rows; ?></span>

            </div>

            <div class="table-responsive">

                <table class="table-custom">

                    <thead>

                        <tr>

                            <th>Service & Platform</th>

                            <th>Cost</th>

                            <th>Status</th>

                            <th>Time</th>

                            <th class="text-end">Action</th>

                        </tr>

                    </thead>

                    <tbody>

                        <?php 

                        if ($orders->num_rows > 0) {

                            while($row = $orders->fetch_assoc()) {

                                // Status Logic

                                $st = $row['status'];

                                $cls = 'st-pending'; $icon = 'fa-clock';

                                if($st=='Completed' || $st=='Success') { $cls='st-success'; $icon='fa-check'; }

                                elseif($st=='Canceled' || $st=='Rejected') { $cls='st-cancel'; $icon='fa-times'; }

                                elseif($st=='In Progress') { $cls='st-process'; $icon='fa-spinner fa-spin'; }

                                $fullData = htmlspecialchars($row['link']);

                                

                                // FIX: Double Quotes replaced with Single Quotes inside echo

                                echo "<tr>

                                    <td>

                                        <div class='service-name' title='".htmlspecialchars($row['service_name'])."'>".htmlspecialchars($row['service_name'])."</div>

                                        <small class='text-muted' style='font-size:10px;'>ID: #{$row['id']}</small>

                                    </td>

                                    

                                    <td>

                                        <span class='fw-bold text-dark'>$".number_format($row['charge'], 4)."</span>

                                    </td>

                                    

                                    <td>

                                        <span class='badge-status $cls'><i class='fas $icon'></i> $st</span>

                                    </td>

                                    <td>

                                        <small class='text-muted'>".date('d M, h:i A', strtotime($row['created_at']))."</small>

                                    </td>

                                    

                                    <td class='text-end'>

                                        <button class='btn-icon btn-view view-btn' 

                                            data-id='{$row['id']}'

                                            data-service='".htmlspecialchars($row['service_name'])."'

                                            data-link='$fullData'

                                            data-charge='{$row['charge']}'

                                            data-qty='{$row['quantity']}'

                                            data-status='$st'

                                            data-date='".date('d M Y, h:i A', strtotime($row['created_at']))."'>

                                            <i class='fas fa-eye'></i>

                                        </button>

                                        <button class='btn-icon btn-del' onclick=\"confirmDelete({$row['id']})\">

                                            <i class='fas fa-trash-alt'></i>

                                        </button>

                                    </td>

                                </tr>";

                            }

                        } else {

                            echo "<tr><td colspan='5' class='text-center py-4 text-muted small'>No orders found.</td></tr>";

                        }

                        ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>

</div>

<div class="modal fade" id="detailsModal" tabindex="-1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-sm">

        <div class="modal-content">

            <div class="modal-header py-3">

                <h6 class="modal-title m-0 fw-bold">Order Details <span id="m_id" class="opacity-75"></span></h6>

                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>

            </div>

            <div class="modal-body">

                <div class="detail-row">

                    <span class="detail-label">Service</span>

                    <span id="m_service" class="detail-val text-primary text-truncate" style="max-width: 150px;"></span>

                </div>

                <div class="detail-row">

                    <span class="detail-label">Quantity</span>

                    <span id="m_qty" class="detail-val"></span>

                </div>

                <div class="detail-row">

                    <span class="detail-label">Total Cost</span>

                    <span class="detail-val text-success fw-bold">$<span id="m_charge"></span></span>

                </div>

                <div class="detail-row">

                    <span class="detail-label">Date</span>

                    <span id="m_date" class="detail-val small"></span>

                </div>

                <div class="detail-row border-0">

                    <span class="detail-label">Status</span>

                    <div id="m_status"></div>

                </div>

                

                <div class="mt-3">

                    <small class="fw-bold text-muted text-uppercase" style="font-size:10px;">Input Data / Link</small>

                    <div id="m_data" class="data-box"></div>

                </div>

            </div>

        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>

    AOS.init({ once: true });

    const modal = new bootstrap.Modal(document.getElementById('detailsModal'));

    document.querySelectorAll('.view-btn').forEach(btn => {

        btn.addEventListener('click', function() {

            document.getElementById('m_id').innerText = '#' + this.dataset.id;

            document.getElementById('m_service').innerText = this.dataset.service;

            document.getElementById('m_qty').innerText = this.dataset.qty;

            document.getElementById('m_charge').innerText = this.dataset.charge;

            document.getElementById('m_date').innerText = this.dataset.date;

            

            let formattedData = this.dataset.link.replace(/ \| /g, '<br>');

            document.getElementById('m_data').innerHTML = formattedData;

            let st = this.dataset.status;

            let badgeClass = 'bg-secondary';

            if(st === 'Completed' || st === 'Success') badgeClass = 'bg-success';

            else if(st === 'Pending') badgeClass = 'bg-warning text-dark';

            else if(st === 'Canceled') badgeClass = 'bg-danger';

            

            document.getElementById('m_status').innerHTML = `<span class="badge ${badgeClass}">${st}</span>`;

            modal.show();

        });

    });

    function confirmDelete(id) {

        Swal.fire({

            title: 'Delete?',

            icon: 'warning',

            showCancelButton: true,

            confirmButtonColor: '#ef4444',

            confirmButtonText: 'Yes',

            cancelButtonText: 'No',

            customClass: { popup: 'swal-small' }

        }).then((result) => {

            if (result.isConfirmed) {

                window.location.href = `history.php?delete_id=${id}`;

            }

        });

    }

    <?php if(isset($_GET['msg']) && $_GET['msg'] == 'deleted'): ?>

    const Toast = Swal.mixin({ toast: true, position: 'top-end', showConfirmButton: false, timer: 3000 });

    Toast.fire({ icon: 'success', title: 'Deleted' });

    <?php endif; ?>

</script>

<style>

    .swal-small { font-size: 12px; width: 300px !important; }

</style>

</body>

</html>