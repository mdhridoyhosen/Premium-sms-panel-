<?php
session_start();
include 'db.php';

// অটো লগইন এবং সেশন চেক
if (isset($_COOKIE['user_login']) && !isset($_SESSION['username'])) {
    $_SESSION['username'] = $_COOKIE['user_login'];
    header("Location: dashboard.php");
    exit();
}
if (isset($_SESSION['username'])) {
    header("Location: dashboard.php");
    exit();
}

$swal_status = ""; $swal_title = ""; $swal_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // --- LOGIN ---
    if (isset($_POST['action']) && $_POST['action'] == 'login') {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = $_POST['password'];

        $sql = "SELECT * FROM users WHERE username = '$username'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            if ($password == $row['password']) {
                $_SESSION['username'] = $username;
                if(isset($_POST['remember'])){
                    setcookie("user_login", $username, time() + (86400 * 30), "/");
                }
                header("Location: dashboard.php");
                exit();
            } else {
                $swal_status = "error"; $swal_title = "Access Denied"; $swal_msg = "Incorrect password provided.";
            }
        } else {
            $swal_status = "warning"; $swal_title = "User Not Found"; $swal_msg = "This username is not registered.";
        }
    }
    // --- SIGNUP ---
    elseif (isset($_POST['action']) && $_POST['action'] == 'signup') {
        $user = mysqli_real_escape_string($conn, $_POST['reg_username']);
        $email = mysqli_real_escape_string($conn, $_POST['reg_email']);
        $pass = $_POST['reg_password'];
        $cpass = $_POST['reg_cpassword'];
        
        // রেফার কোড ইনপুট নেওয়া হচ্ছে
        $ref = mysqli_real_escape_string($conn, $_POST['refer_code']);

        if ($pass !== $cpass) {
            $swal_status = "error"; $swal_title = "Password Mismatch"; $swal_msg = "Your passwords do not match.";
        } else {
            $check_query = "SELECT * FROM users WHERE username='$user' OR email='$email' LIMIT 1";
            $result = $conn->query($check_query);

            if ($result->num_rows > 0) {
                $swal_status = "error"; $swal_title = "Already Exists"; $swal_msg = "Username or Email is already in use.";
            } else {
                // ডাটাবেসে রেফার কোড সহ ইনসার্ট করা হচ্ছে
                $sql = "INSERT INTO users (username, email, password, refer_code) VALUES ('$user', '$email', '$pass', '$ref')";
                
                if ($conn->query($sql) === TRUE) {
                    $_SESSION['username'] = $user;
                    $swal_status = "success"; $swal_title = "Account Created"; $swal_msg = "Welcome aboard!";
                } else {
                    $swal_status = "error"; $swal_title = "System Error"; $swal_msg = "Database connection failed.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FTCSMM - Premium Login</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Urbanist:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        /* Base Styles */
        body {
            font-family: 'Urbanist', sans-serif;
            background: #0f0c29;  
            background: linear-gradient(to right, #24243e, #302b63, #0f0c29);
            color: #fff;
            overflow-x: hidden;
            min-height: 100vh;
        }

        /* --- STYLISH NAVBAR --- */
        .navbar-custom {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 50px;
            margin-top: 20px;
            padding: 10px 25px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.3);
            transition: all 0.3s ease;
        }

        .navbar-brand {
            font-weight: 800;
            font-size: 1.5rem;
            background: linear-gradient(to right, #ff00cc, #783DC9);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .nav-link {
            color: rgba(255,255,255,0.7) !important;
            font-weight: 600;
            transition: 0.3s;
            margin: 0 10px;
            position: relative;
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            width: 0;
            height: 2px;
            bottom: 0;
            left: 50%;
            background: #ff00cc;
            transition: all 0.3s ease;
            transform: translateX(-50%);
        }
        
        .nav-link:hover { color: #fff !important; }
        .nav-link:hover::after { width: 100%; }

        /* --- ANIMATED HAMBURGER ICON --- */
        .navbar-toggler {
            border: none;
            padding: 0;
            box-shadow: none !important;
        }
        .menu-icon {
            width: 30px;
            height: 20px;
            position: relative;
            transform: rotate(0deg);
            transition: .5s ease-in-out;
            cursor: pointer;
        }
        .menu-icon span {
            display: block;
            position: absolute;
            height: 3px;
            width: 100%;
            background: #fff;
            border-radius: 9px;
            opacity: 1;
            left: 0;
            transform: rotate(0deg);
            transition: .25s ease-in-out;
        }
        .menu-icon span:nth-child(1) { top: 0px; }
        .menu-icon span:nth-child(2) { top: 8px; }
        .menu-icon span:nth-child(3) { top: 16px; }

        .navbar-toggler[aria-expanded="true"] .menu-icon span:nth-child(1) {
            top: 8px;
            transform: rotate(135deg);
            background: #ff00cc;
        }
        .navbar-toggler[aria-expanded="true"] .menu-icon span:nth-child(2) {
            opacity: 0;
            left: -60px;
        }
        .navbar-toggler[aria-expanded="true"] .menu-icon span:nth-child(3) {
            top: 8px;
            transform: rotate(-135deg);
            background: #ff00cc;
        }

        /* --- HERO & FORM --- */
        .hero-section {
            padding-top: 100px;
            min-height: 85vh;
            display: flex;
            align-items: center;
        }

        /* RGB Border Card */
        .rgb-wrapper {
            position: relative;
            border-radius: 20px;
            padding: 3px;
            background: linear-gradient(60deg, #ff00cc, #333399, #00d4ff);
            background-size: 300% 300%;
            animation: gradient-anim 3s alternate infinite;
            box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        }
        @keyframes gradient-anim {
            0% { background-position: 0% 50%; }
            50% { background-position: 100% 50%; }
            100% { background-position: 0% 50%; }
        }

        .auth-card {
            background: #111;
            border-radius: 17px;
            padding: 2.5rem;
            height: 100%;
        }

        /* Inputs */
        .form-control {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            color: #fff; padding: 12px; border-radius: 10px;
        }
        .form-control:focus {
            background: rgba(255,255,255,0.1);
            border-color: #ff00cc;
            box-shadow: none;
            color: #fff;
        }
        .form-control::placeholder { color: rgba(255,255,255,0.6); }
        .input-group-text { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-right: none; color: #ff00cc; }
        .form-control { border-left: none; }

        /* Tabs */
        .nav-pills .nav-link { color: rgba(255,255,255,0.6); margin: 0 5px; border-radius: 30px; transition: 0.3s; }
        .nav-pills .nav-link.active { background: linear-gradient(90deg, #ff00cc, #333399); color: #fff; font-weight: 700; box-shadow: 0 5px 15px rgba(255, 0, 204, 0.4); }

        /* Button */
        .btn-glow {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 10px;
            background: #fff;
            color: #000;
            font-weight: 800;
            transition: 0.3s;
        }
        .btn-glow:hover {
            background: #ff00cc;
            color: #fff;
            box-shadow: 0 0 20px #ff00cc;
        }

        /* --- BOTTOM CONTENT --- */
        .info-card {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(255,255,255,0.05);
            padding: 25px; border-radius: 15px; transition: 0.3s;
        }
        .info-card:hover { transform: translateY(-5px); border-color: #ff00cc; }
        
        .accordion-item { background: transparent; border: 1px solid rgba(255,255,255,0.1); margin-bottom: 10px; border-radius: 10px !important; }
        .accordion-button { background: rgba(255,255,255,0.02); color: #fff; font-weight: 600; }
        .accordion-button:not(.collapsed) { background: rgba(255, 0, 204, 0.1); color: #ff00cc; box-shadow: none; }
        .accordion-button:focus { box-shadow: none; }
        .accordion-body { color: rgba(255,255,255,0.7); }

        footer { border-top: 1px solid rgba(255,255,255,0.1); background: rgba(0,0,0,0.3); margin-top: 60px; padding: 40px 0; }

        @media (max-width: 991px) {
            .navbar-custom { border-radius: 15px; margin: 10px; }
            .hero-section { padding-top: 50px; text-align: center; flex-direction: column; }
            .hero-text { margin-bottom: 40px; }
        }
    </style>
</head>
<body>

    <div class="container sticky-top">
        <nav class="navbar navbar-expand-lg navbar-custom">
            <div class="container-fluid">
                <a class="navbar-brand" href="#"><i class="fas fa-bolt me-2"></i>
          𝔽𝕋ℂ𝕊𝕄𝕄      
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                    <div class="menu-icon">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </button>

                <div class="collapse navbar-collapse" id="mainNav">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center">
                        <li class="nav-item"><a class="nav-link" href="#">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="service.html">Services</a></li>
                        <li class="nav-item"><a class="nav-link" href="API.php">API</a></li>
                        <li class="nav-item ms-lg-2">
                            <a href="https://wa.me/8801811925142" class="btn btn-sm rounded-pill px-4 text-white" style="background: linear-gradient(90deg, #ff00cc, #333399);">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>

    <section class="container hero-section">
        <div class="row align-items-center w-100 m-0">
            
            <div class="col-lg-6 hero-text" data-aos="fade-right">
                <span class="badge rounded-pill mb-3 px-3 py-2" style="background: rgba(255,0,204,0.1); color: #ff00cc; border: 1px solid #ff00cc;">🚀 Best SMM Panel</span>
                <h1 class="display-3 fw-bold mb-3">Boost Your <br> <span style="color: #ff00cc;">Digital Presence</span></h1>
                <p class="lead text-white-50 mb-4">
                    The #1 Rated SMM Panel. We provide the cheapest & fastest services for all social media platforms.
                </p>
                <div class="d-flex gap-3 justify-content-lg-start justify-content-center">
                    <div class="text-white small"><i class="fas fa-check-circle text-success me-1"></i> No Drop</div>
                    <div class="text-white small"><i class="fas fa-check-circle text-success me-1"></i> Instant</div>
                    <div class="text-white small"><i class="fas fa-check-circle text-success me-1"></i> Secure</div>
                </div>
            </div>

            <div id="loginasiup"class="col-lg-5 offset-lg-1" data-aos="zoom-in">
                <div class="rgb-wrapper">
                    <div class="auth-card">
                        <ul class="nav nav-pills nav-justified mb-4" id="pills-tab" role="tablist">
                            <li class="nav-item"><button class="nav-link active" id="login-tab" data-bs-toggle="pill" data-bs-target="#login" type="button">Login</button></li>
                            <li class="nav-item"><button class="nav-link" id="signup-tab" data-bs-toggle="pill" data-bs-target="#signup" type="button">Register</button></li>
                        </ul>

                        <div class="tab-content">
                            <div class="tab-pane fade show active" id="login">
                                <form method="POST">
                                    <input type="hidden" name="action" value="login">
                                    <div class="mb-3 input-group">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                                    </div>
                                    <div class="mb-3 input-group">
                                        <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                                    </div>
                                    <div class="d-flex justify-content-between mb-4 small">
                                        <div class="form-check">
                                            <input class="form-check-input bg-dark border-secondary" type="checkbox" name="remember" checked>
                                            <label class="form-check-label text-white-50">Remember</label>
                                        </div>
                                        <a href="#" class="text-decoration-none" style="color: #ff00cc;">Forgot?</a>
                                    </div>
                                    <button type="submit" class="btn-glow">SECURE LOGIN</button>
                                </form>
                            </div>

                            <div class="tab-pane fade" id="signup">
                                <form method="POST">
                                    <input type="hidden" name="action" value="signup">
                                    <div class="mb-3 input-group">
                                        <span class="input-group-text"><i class="fas fa-user"></i></span>
                                        <input type="text" name="reg_username" class="form-control" placeholder="Username" required>
                                    </div>
                                    <div class="mb-3 input-group">
                                        <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                        <input type="email" name="reg_email" class="form-control" placeholder="Email" required>
                                    </div>
                                    <div class="mb-3 input-group">
                                        <span class="input-group-text"><i class="fas fa-key"></i></span>
                                        <input type="password" name="reg_password" class="form-control" placeholder="Password" required>
                                    </div>
                                    <div class="mb-3 input-group">
                                        <span class="input-group-text"><i class="fas fa-check-circle"></i></span>
                                        <input type="password" name="reg_cpassword" class="form-control" placeholder="Confirm Password" required>
                                    </div>
                                    
                                    <div class="mb-3 input-group">
                                        <span class="input-group-text"><i class="fas fa-gift"></i></span>
                                        <input type="text" name="refer_code" class="form-control" placeholder="Refer Code (Optional)">
                                    </div>

                                    <button type="submit" class="btn-glow">CREATE ACCOUNT</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <section class="container py-5 mt-5">
        <div class="text-center mb-5" data-aos="fade-up">
            <h6 class="text-uppercase" style="color: #ff00cc;">Testimonials</h6>
            <h2 class="fw-bold">Client Feedback</h2>
        </div>
        <div class="row g-4">
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="100">
                <div class="info-card h-100">
                    <div class="mb-3 text-warning"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <p class="text-white-50 small fst-italic">"This panel is absolutely amazing. The API is super fast and the support team is very helpful."</p>
                    <h6 class="text-white mt-3 fw-bold">- John Doe</h6>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="200">
                <div class="info-card h-100">
                    <div class="mb-3 text-warning"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-half"></i></div>
                    <p class="text-white-50 small fst-italic">"I've been using this for 6 months for my clients. Best prices in the market guaranteed."</p>
                    <h6 class="text-white mt-3 fw-bold">- Sarah Khan</h6>
                </div>
            </div>
            <div class="col-md-4" data-aos="fade-up" data-aos-delay="300">
                <div class="info-card h-100">
                    <div class="mb-3 text-warning"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <p class="text-white-50 small fst-italic">"Great experience! The drip-feed feature works perfectly for organic growth."</p>
                    <h6 class="text-white mt-3 fw-bold">- Mike Ross</h6>
                </div>
            </div>
        </div>
    </section>

    <section class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-8" data-aos="fade-up">
                <div class="text-center mb-4">
                    <h2 class="fw-bold">FAQ</h2>
                    <p class="text-white-50">Frequently Asked Questions</p>
                </div>
                <div class="accordion" id="faqAccordion">
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq1">
                                How do I add funds?
                            </button>
                        </h2>
                        <div id="faq1" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Login, go to Add Funds, choose your method (Bkash/Nagad/Crypto), and follow instructions.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq2">
                                Is it safe?
                            </button>
                        </h2>
                        <div id="faq2" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes, we use 100% safe methods. Your account will never be banned.
                            </div>
                        </div>
                    </div>
                    <div class="accordion-item">
                        <h2 class="accordion-header">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#faq3">
                                Do you have API?
                            </button>
                        </h2>
                        <div id="faq3" class="accordion-collapse collapse" data-bs-parent="#faqAccordion">
                            <div class="accordion-body">
                                Yes, we offer full API support for resellers to connect their panels.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container text-center">
            <h5 class="fw-bold mb-3">FTCSMM</h5>
            <div class="d-flex justify-content-center gap-4 mb-4">
                <a href="#" class="text-white-50 text-decoration-none">Terms</a>
                <a href="#" class="text-white-50 text-decoration-none">Privacy</a>
                <a href="#" class="text-white-50 text-decoration-none">API</a>
                <a href="#" class="text-white-50 text-decoration-none">Support</a>
            </div>
            <p class="small text-white-50 mb-0">&copy; 2024 FTCSMM. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <script>
        AOS.init({ once: true });
        
        // Disable Inspect
        document.onkeydown = function(e) {
            if(e.keyCode == 123) return false;
            if(e.ctrlKey && e.shiftKey && (e.keyCode == 'I'.charCodeAt(0) || e.keyCode == 'J'.charCodeAt(0))) return false;
            if(e.ctrlKey && e.keyCode == 'U'.charCodeAt(0)) return false;
        }
    </script>

    <?php if(!empty($swal_status)): ?>
    <script>
        Swal.fire({
            icon: '<?php echo $swal_status; ?>',
            title: '<?php echo $swal_title; ?>',
            text: '<?php echo $swal_msg; ?>',
            background: '#111',
            color: '#fff',
            confirmButtonColor: '#ff00cc'
        }).then(() => {
            if('<?php echo $swal_status; ?>' === 'success') window.location.href = 'dashboard.php';
        });
    </script>
    <?php endif; ?>

</body>
</html>