<?php

session_start();

include 'db.php';

// ১. এডমিন লগইন লজিক (হার্ডকোডেড পাসওয়ার্ড: 1122)

if (isset($_POST['admin_login'])) {

    $pass = $_POST['password'];

    if ($pass === '1122') {

        $_SESSION['admin_logged_in'] = true;

    } else {

        $error = "Incorrect Password!";

    }

}

// লগআউট

if (isset($_GET['logout'])) {

    unset($_SESSION['admin_logged_in']);

    header("Location: admin_deposits.php");

    exit();

}

// লগইন না থাকলে লগইন ফর্ম দেখাবে

if (!isset($_SESSION['admin_logged_in'])) {

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Admin Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>

        body { background: #1a1a2e; height: 100vh; display: flex; align-items: center; justify-content: center; }

        .login-box { background: #fff; padding: 40px; border-radius: 10px; width: 100%; max-width: 400px; }

    </style>

</head>

<body>

    <div class="login-box text-center">

        <h3>Admin Access</h3>

        <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>

        <form method="POST">

            <input type="password" name="password" class="form-control mb-3" placeholder="Enter PIN" required>

            <button type="submit" name="admin_login" class="btn btn-primary w-100">Login</button>

        </form>

    </div>

</body>

</html>

<?php

    exit();

}

// ========================================================

// ⚙️ অ্যাকশন লজিক (Approve / Reject)

// ========================================================

if (isset($_POST['action'])) {

    $id = $_POST['req_id'];

    $user = $_POST['req_user'];

    $amount = $_POST['req_amount'];

    $action = $_POST['action'];

    if ($action == 'approve') {

        // ১. স্ট্যাটাস আপডেট করা

        $update_sql = "UPDATE deposits SET status='Success' WHERE id='$id'";

        

        // ২. ইউজারের ব্যালেন্স যোগ করা

        $balance_sql = "UPDATE users SET balance = balance + $amount WHERE username='$user'";

        

        // ৩. ইউজারের জন্য নোটিফিকেশন মেসেজ সেট করা

        $msg = "Deposit Approved! $amount BDT has been added to your account.";

        $notif_sql = "UPDATE users SET notification_update='$msg' WHERE username='$user'";

        if ($conn->query($update_sql) && $conn->query($balance_sql) && $conn->query($notif_sql)) {

            $alert = "swal.fire('Success', 'Fund added to user account!', 'success');";

        }

    } 

    elseif ($action == 'reject') {

        // ১. স্ট্যাটাস রিজেক্ট করা

        $update_sql = "UPDATE deposits SET status='Rejected' WHERE id='$id'";

        

        // ২. রিজেকশন মেসেজ সেট করা

        $msg = "Deposit Rejected! TrxID or Info incorrect. Please contact support.";

        $notif_sql = "UPDATE users SET notification_update='$msg' WHERE username='$user'";

        if ($conn->query($update_sql) && $conn->query($notif_sql)) {

            $alert = "swal.fire('Rejected', 'Request marked as invalid.', 'warning');";

        }

    }

}

// পেন্ডিং রিকোয়েস্ট লিস্ট আনা

$sql = "SELECT * FROM deposits ORDER BY id DESC";

$result = $conn->query($sql);

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Deposit Manager - Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>

        body { background: #f4f6f9; font-family: 'Segoe UI', sans-serif; }

        .navbar { background: #343a40; }

        .navbar-brand { color: #fff; font-weight: bold; }

        .card { border: none; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }

        .badge-pending { background: #ffc107; color: #000; }

        .badge-success { background: #28a745; }

        .badge-rejected { background: #dc3545; }

        .btn-action { width: 35px; height: 35px; padding: 0; line-height: 35px; text-align: center; border-radius: 50%; }

    </style>

</head>

<body>

<nav class="navbar navbar-expand-lg px-4">

    <a class="navbar-brand" href="#"><i class="fas fa-user-shield me-2"></i>Admin Panel</a>

    <a href="?logout=true" class="btn btn-outline-light btn-sm ms-auto">Logout</a>

</nav>

<div class="container py-5">

    <div class="row">

        <div class="col-12">

            <h4 class="mb-4 text-secondary">Manage Deposit Requests</h4>

            <div class="card p-3">

                <div class="table-responsive">

                    <table class="table table-hover align-middle">

                        <thead class="table-light">

                            <tr>

                                <th>#ID</th>

                                <th>User</th>

                                <th>Method</th>

                                <th>Amount</th>

                                <th>TrxID</th>

                                <th>Date</th>

                                <th>Status</th>

                                <th>Action</th>

                            </tr>

                        </thead>

                        <tbody>

                            <?php 

                            if ($result->num_rows > 0) {

                                while($row = $result->fetch_assoc()) {

                                    $status = $row['status'];

                                    $badge = 'badge-pending';

                                    if($status == 'Success') $badge = 'badge-success';

                                    if($status == 'Rejected') $badge = 'badge-rejected';

                                    

                                    // বাটন ডিজেবল লজিক (যদি ইতিমধ্যে এপ্রুভ/রিজেক্ট হয়ে থাকে)

                                    $disabled = ($status != 'Pending') ? 'disabled' : '';

                                    echo "<tr>

                                        <td>#{$row['id']}</td>

                                        <td class='fw-bold text-primary'>{$row['username']}</td>

                                        <td>".strtoupper($row['method'])."</td>

                                        <td class='fw-bold text-success'>৳{$row['amount']}</td>

                                        <td><code>{$row['trx_id']}</code></td>

                                        <td class='small text-muted'>".date('d M, h:i A', strtotime($row['created_at']))."</td>

                                        <td><span class='badge $badge'>$status</span></td>

                                        <td>

                                            <form method='POST' style='display:inline-block;' onsubmit='return confirm(\"Are you sure to APPROVE this?\");'>

                                                <input type='hidden' name='req_id' value='{$row['id']}'>

                                                <input type='hidden' name='req_user' value='{$row['username']}'>

                                                <input type='hidden' name='req_amount' value='{$row['amount']}'>

                                                <input type='hidden' name='action' value='approve'>

                                                <button class='btn btn-success btn-action btn-sm' title='Approve' $disabled>

                                                    <i class='fas fa-check'></i>

                                                </button>

                                            </form>

                                            <form method='POST' style='display:inline-block;' onsubmit='return confirm(\"Reject this request?\");'>

                                                <input type='hidden' name='req_id' value='{$row['id']}'>

                                                <input type='hidden' name='req_user' value='{$row['username']}'>

                                                <input type='hidden' name='action' value='reject'>

                                                <button class='btn btn-danger btn-action btn-sm' title='Reject' $disabled>

                                                    <i class='fas fa-times'></i>

                                                </button>

                                            </form>

                                        </td>

                                    </tr>";

                                }

                            } else {

                                echo "<tr><td colspan='8' class='text-center py-4'>No requests found.</td></tr>";

                            }

                            ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>

<script>

    // পিএইচপি থেকে আসা এলার্ট চালানো

    <?php if(isset($alert)) echo $alert; ?>

</script>

</body>

</html>