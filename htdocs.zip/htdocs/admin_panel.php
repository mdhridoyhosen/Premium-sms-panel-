<?php

session_start();

include 'db.php';

// লগইন চেক

if (!isset($_SESSION['is_admin'])) {

    if(isset($_POST['login']) && $_POST['pass'] == '1122') $_SESSION['is_admin'] = true;

    else { echo '<form method="POST" style="margin:100px auto; width:300px;"><input type="password" name="pass" placeholder="PIN" style="width:100%; padding:10px;"><button name="login" style="width:100%; padding:10px; margin-top:5px;">Login</button></form>'; exit(); }

}

// --- ব্যাকএন্ড লজিক ---

// ১. প্ল্যাটফর্ম অ্যাড/এডিট/ডিলিট

if (isset($_POST['save_platform'])) {

    $name = $_POST['p_name'];

    $icon = $_POST['p_icon'];

    $pid = $_POST['p_id'];

    if ($pid) { // Update

        $conn->query("UPDATE platforms SET name='$name', icon_url='$icon' WHERE id='$pid'");

    } else { // Insert

        $conn->query("INSERT INTO platforms (name, icon_url) VALUES ('$name', '$icon')");

    }

    header("Location: admin_panel.php");

}

if (isset($_GET['del_platform'])) {

    $id = $_GET['del_platform'];

    $conn->query("DELETE FROM platforms WHERE id='$id'");

    header("Location: admin_panel.php");

}

// ২. সার্ভিস অ্যাড/এডিট/ডিলিট

if (isset($_POST['save_service'])) {

    $sid = $_POST['s_id'];

    $pid = $_POST['platform_id'];

    $name = $_POST['s_name'];

    $price = $_POST['price'];

    $min = $_POST['min_qty'];

    $max = $_POST['max_qty'];

    

    // ডায়নামিক ইনপুট প্রসেসিং

    $inputs = [];

    if(!empty($_POST['field_labels'])) {

        foreach($_POST['field_labels'] as $k => $label) {

            $inputs[] = [

                'label' => $label,

                'type' => $_POST['field_types'][$k],

                'options' => $_POST['field_options'][$k]

            ];

        }

    }

    $json_config = json_encode($inputs);

    if ($sid) { // Update

        $stmt = $conn->prepare("UPDATE services SET platform_id=?, service_name=?, price=?, min_qty=?, max_qty=?, input_config=? WHERE id=?");

        $stmt->bind_param("isdiisi", $pid, $name, $price, $min, $max, $json_config, $sid);

    } else { // Insert

        $stmt = $conn->prepare("INSERT INTO services (platform_id, service_name, price, min_qty, max_qty, input_config) VALUES (?, ?, ?, ?, ?, ?)");

        $stmt->bind_param("isdiis", $pid, $name, $price, $min, $max, $json_config);

    }

    $stmt->execute();

    header("Location: admin_panel.php");

}

if (isset($_GET['del_service'])) {

    $id = $_GET['del_service'];

    $conn->query("DELETE FROM services WHERE id='$id'");

    header("Location: admin_panel.php");

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

    <meta charset="UTF-8">

    <title>Super Admin Panel</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <style>

        body { background: #f4f6f9; }

        .card { border: none; shadow: 0 2px 10px rgba(0,0,0,0.1); }

        .platform-icon { width: 30px; height: 30px; object-fit: contain; }

    </style>

</head>

<body class="p-4">

<div class="container-fluid">

    <div class="row">

        

        <div class="col-md-4">

            <div class="card p-3 mb-4">

                <h5 class="fw-bold text-primary"><i class="fas fa-layer-group"></i> প্ল্যাটফর্ম ম্যানেজার</h5>

                <form method="POST" id="platformForm">

                    <input type="hidden" name="p_id" id="p_id">

                    <div class="mb-2">

                        <label class="small fw-bold">প্ল্যাটফর্ম নাম</label>

                        <input type="text" name="p_name" id="p_name" class="form-control" placeholder="Ex: Facebook" required>

                    </div>

                    <div class="mb-2">

                        <label class="small fw-bold">আইকন লিংক (URL)</label>

                        <input type="text" name="p_icon" id="p_icon" class="form-control" placeholder="https://example.com/icon.png">

                    </div>

                    <button type="submit" name="save_platform" class="btn btn-primary w-100 btn-sm">সেভ প্ল্যাটফর্ম</button>

                    <button type="button" onclick="resetPlatform()" class="btn btn-secondary w-100 btn-sm mt-1" style="display:none" id="resetPBtn">Cancel Edit</button>

                </form>

                <hr>

                

                <div style="max-height: 400px; overflow-y: auto;">

                    <ul class="list-group">

                        <?php

                        $plat_res = $conn->query("SELECT * FROM platforms");

                        while($p = $plat_res->fetch_assoc()) {

                            echo "<li class='list-group-item d-flex justify-content-between align-items-center'>

                                <div>

                                    <img src='{$p['icon_url']}' class='platform-icon me-2' onerror=\"this.src='https://via.placeholder.com/30'\">

                                    <strong>{$p['name']}</strong>

                                </div>

                                <div>

                                    <button onclick='editPlatform(".json_encode($p).")' class='btn btn-warning btn-sm py-0'><i class='fas fa-edit'></i></button>

                                    <a href='?del_platform={$p['id']}' onclick='return confirm(\"মুছে ফেলবেন?\")' class='btn btn-danger btn-sm py-0'><i class='fas fa-trash'></i></a>

                                </div>

                            </li>";

                        }

                        ?>

                    </ul>

                </div>

            </div>

        </div>

        <div class="col-md-8">

            <div class="card p-3">

                <div class="d-flex justify-content-between">

                    <h5 class="fw-bold text-success"><i class="fas fa-cogs"></i> সার্ভিস এডিটর</h5>

                    <button type="button" onclick="resetService()" class="btn btn-sm btn-outline-secondary">Reset Form</button>

                </div>

                <form method="POST" id="serviceForm">

                    <input type="hidden" name="s_id" id="s_id">

                    

                    <div class="row g-2">

                        <div class="col-md-4">

                            <label class="small fw-bold">প্ল্যাটফর্ম সিলেক্ট</label>

                            <select name="platform_id" id="s_pid" class="form-select" required>

                                <?php

                                $plat_res = $conn->query("SELECT * FROM platforms");

                                while($p = $plat_res->fetch_assoc()) {

                                    echo "<option value='{$p['id']}'>{$p['name']}</option>";

                                }

                                ?>

                            </select>

                        </div>

                        <div class="col-md-8">

                            <label class="small fw-bold">সার্ভিসের নাম</label>

                            <input type="text" name="s_name" id="s_name" class="form-control" required>

                        </div>

                        <div class="col-md-4">

                            <label class="small fw-bold">দাম (প্রতি ইউনিট)</label>

                            <input type="number" step="0.0001" name="price" id="s_price" class="form-control" required>

                        </div>

                        <div class="col-md-4">

                            <label class="small fw-bold">Min Qty</label>

                            <input type="number" name="min_qty" id="s_min" class="form-control" value="10">

                        </div>

                        <div class="col-md-4">

                            <label class="small fw-bold">Max Qty</label>

                            <input type="number" name="max_qty" id="s_max" class="form-control" value="10000">

                        </div>

                    </div>

                    <div class="mt-3 p-2 border rounded bg-light">

                        <label class="fw-bold text-dark">📝 ইনপুট ফিল্ড কনফিগারেশন</label>

                        <div id="fields_container"></div>

                        <button type="button" class="btn btn-sm btn-outline-primary mt-2" onclick="addField()">+ আরো ইনপুট যোগ করুন</button>

                    </div>

                    <button type="submit" name="save_service" class="btn btn-success w-100 mt-3 fw-bold">সেভ / আপডেট সার্ভিস</button>

                </form>

                <div class="mt-4">

                    <h6>সার্ভিস তালিকা:</h6>

                    <table class="table table-sm table-bordered">

                        <thead><tr><th>ID</th><th>Platform</th><th>Service</th><th>Price</th><th>Action</th></tr></thead>

                        <tbody>

                            <?php

                            $svc_res = $conn->query("SELECT s.*, p.name as pname FROM services s LEFT JOIN platforms p ON s.platform_id = p.id ORDER BY s.id DESC");

                            while($s = $svc_res->fetch_assoc()) {

                                echo "<tr>

                                    <td>{$s['id']}</td>

                                    <td>{$s['pname']}</td>

                                    <td>{$s['service_name']}</td>

                                    <td>{$s['price']}</td>

                                    <td>

                                        <button onclick='editService(".json_encode($s).")' class='btn btn-warning btn-sm'>Edit</button>

                                        <a href='?del_service={$s['id']}' onclick='return confirm(\"Sure?\")' class='btn btn-danger btn-sm'>Del</a>

                                    </td>

                                </tr>";

                            }

                            ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>

<script>

// --- Platform Functions ---

function editPlatform(data) {

    $("#p_id").val(data.id);

    $("#p_name").val(data.name);

    $("#p_icon").val(data.icon_url);

    $("#resetPBtn").show();

}

function resetPlatform() {

    $("#platformForm")[0].reset();

    $("#p_id").val('');

    $("#resetPBtn").hide();

}

// --- Service Functions ---

function addField(label='', type='text', options='') {

    let html = `

    <div class="input-group mb-2 field-row">

        <input type="text" name="field_labels[]" class="form-control" placeholder="Label (Ex: Post Link)" value="${label}" required>

        <select name="field_types[]" class="form-select">

            <option value="text" ${type=='text'?'selected':''}>Text Input</option>

            <option value="url" ${type=='url'?'selected':''}>Link/URL</option>

            <option value="file" ${type=='file'?'selected':''}>File Upload</option>

            <option value="select" ${type=='select'?'selected':''}>Dropdown</option>

            <option value="multiselect" ${type=='multiselect'?'selected':''}>Multi-Select</option>

        </select>

        <input type="text" name="field_options[]" class="form-control" placeholder="Options (koman,diye,likhun)" value="${options}">

        <button type="button" class="btn btn-danger" onclick="this.parentElement.remove()">X</button>

    </div>`;

    $("#fields_container").append(html);

}

function editService(data) {

    // Basic Data Populate

    $("#s_id").val(data.id);

    $("#s_pid").val(data.platform_id);

    $("#s_name").val(data.service_name);

    $("#s_price").val(data.price);

    $("#s_min").val(data.min_qty);

    $("#s_max").val(data.max_qty);

    // Input Config Populate

    $("#fields_container").empty();

    let config = JSON.parse(data.input_config);

    if(config) {

        config.forEach(field => {

            addField(field.label, field.type, field.options);

        });

    }

    // Scroll to top

    $('html, body').animate({ scrollTop: 0 }, 'fast');

}

function resetService() {

    $("#serviceForm")[0].reset();

    $("#s_id").val('');

    $("#fields_container").empty();

    addField(); // Add one empty field by default

}

// Init

$(document).ready(function() {

    addField(); // Default one field

});

</script>

</body>

</html>