<?php
session_start();

/* Session destroy */
$_SESSION = [];
session_unset();
session_destroy();

/* All cookies delete */
if (isset($_SERVER['HTTP_COOKIE'])) {
    $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
    foreach ($cookies as $cookie) {
        $parts = explode('=', $cookie);
        $name = trim($parts[0]);
        setcookie($name, '', time() - 3600, '/');
        setcookie($name, '', time() - 3600, '/', $_SERVER['HTTP_HOST']);
    }
}

/* Redirect to index.php */
header("Location: index.php");
exit;