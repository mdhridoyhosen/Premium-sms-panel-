<?php
session_start();
include 'db.php';

// ইউজার লগইন চেক
if (!isset($_SESSION['username'])) { header("Location: index.php"); exit(); }
$user = $_SESSION['username'];

// ইউজার ডাটা এবং অর্ডার কাউন্ট ফেচিং
// (নোট: তোমার ডাটাবেসে refer_code বা total_orders কলাম না থাকলে এগুলো বানিয়ে নিও অথবা কোড থেকে বাদ দিও)
$u_res = $conn->query("SELECT * FROM users WHERE username='$user'");
$userData = $u_res->fetch_assoc();

// মোট অর্ডার কাউন্ট বের করা (যদি orders টেবিল থাকে)
$order_count_query = $conn->query("SELECT COUNT(*) as total FROM orders WHERE username='$user'");
$orderData = $order_count_query->fetch_assoc();
// ৩. ড্যাশবোর্ড স্ট্যাটাস ডাটা (আপনার কলাম অনুযায়ী আপডেট করা)
$total_orders = $userData['total_order'] ?? 0; // আপনার ডাটাবেস কলাম: total_order
$notification_text = !empty($userData['notification_update']) ? $userData['notification_update'] : "Welcome back! No new updates."; 
// রেফারেল কোড জেনারেট করা

$referral_code = "RF-" . strtoupper($user);

// আপনার ডাটাবেস কলাম: notification_update
// যদি ডাটাবেসে refer_code না থাকে, তবে ডেমো ভ্যালু দেখাবে
$refer_code = $userData['refer_code'] ?? 'REF-'.$userData['id'].'X'; 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary: #6366f1;
            --secondary: #4f46e5;
            --dark-bg: #111827;
            --light-bg: #f8fafc;
            --card-bg: #ffffff;
            --text-color: #334155;
        }
        
        body { 
            font-family: 'Poppins', sans-serif; 
            background: #D9DEEE; 
            font-size: 13px; /* ফন্ট সাইজ ছোট করা হয়েছে */
            color: var(--text-color);
            overflow-x: hidden;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 250px; height: 100vh; position: fixed; top: 0; left: 0;
            background: var(--dark-bg); color: #9ca3af; transition: 0.3s; z-index: 1000;
            overflow-y: auto; /* মেনু বেশি হলে স্ক্রল হবে */
            scrollbar-width: thin;
        }
        .sidebar::-webkit-scrollbar { width: 5px; }
        .sidebar::-webkit-scrollbar-thumb { background: #374151; }

        .sidebar-brand { 
            padding: 20px; font-size: 20px; font-weight: 700; color: #fff; 
            border-bottom: 1px solid rgba(255,255,255,0.1); margin-bottom: 10px;
        }
        .sidebar-brand i { color: var(--primary); }

        .nav-item { 
            padding: 10px 20px; display: flex; align-items: center; color: #9ca3af; 
            text-decoration: none; transition: 0.2s; font-size: 13px; font-weight: 500;
        }
        .nav-item:hover, .nav-item.active { background: rgba(255,255,255,0.2); color: #fff; border-right: 3px solid var(--primary); }
        .nav-item i { width: 25px; font-size: 14px; text-align: center; margin-right: 10px; }
        
        .sidebar-divider { border-top: 1px solid rgba(255,255,255,0.1); margin: 10px 0; }

        /* Main Content */
        .main-content { margin-left: 250px; padding: 20px; transition: 0.3s; }
        
        /* Top Bar */
        .top-bar {
            display: flex; justify-content: space-between; align-items: center;
            margin-bottom: 25px;
        }
        .menu-btn { cursor: pointer; font-size: 20px; color: var(--dark-bg); display: none; }

        /* Overlay for Mobile */
        .overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.5); z-index: 999; display: none; opacity: 0; transition: 0.3s;
        }
        .overlay.active { display: block; opacity: 1; }

        /* Stats Box Styling (2x2 Grid) */
        .stat-card {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 15px;
            display: flex;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
            border: 1px solid #e2e8f0;
            transition: 0.3s;
            height: 100%;
        }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 5px 15px rgba(99, 102, 241, 0.1); }
        
        .stat-icon {
            width: 40px; height: 40px;
            border-radius: 10px;
            display: flex; align-items: center; justify-content: center;
            font-size: 18px;
            margin-right: 12px;
            flex-shrink: 0;
        }
        /* Icon Colors */
        .bg-indigo { background: #e0e7ff; color: #4f46e5; }
        .bg-emerald { background: #d1fae5; color: #059669; }
        .bg-amber { background: #fef3c7; color: #d97706; }
        .bg-rose { background: #ffe4e6; color: #e11d48; }

        .stat-info h6 { margin: 0; font-size: 11px; color: #64748b; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; }
        .stat-info h4 { margin: 2px 0 0 0; font-size: 14px; color: var(--dark-bg); font-weight: 700; word-break: break-all; }

        /* Notification Section */
        .notice-box {
            background: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.03);
            border-left: 4px solid var(--primary);
            margin-top: 30px;
        }
        .notice-header { display: flex; align-items: center; margin-bottom: 15px; }
        .notice-title { font-weight: 700; font-size: 14px; color: var(--dark-bg); }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .sidebar { left: -250px; }
            .sidebar.active { left: 0; }
            .main-content { margin-left: 0; }
            .menu-btn { display: block; }
        }
        
        .dashbvoard-box{
    width: 105% !important;
    min-height: 600px;
    border-radius: 15px; padding:0 !important ; margin: 0!important;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
    background: #fff;
    overflow: hidden; /* iframe feel */
}
    </style>
</head>
<body>

<div class="overlay" id="overlay" onclick="toggleMenu()"></div>

<div class="sidebar" id="sidebar">
    <div class="sidebar-brand">
        <i class="fas fa-bolt"></i> FTC PANEL
    </div>
    
    
    
    
    
  <div class="sidebar-header p-3">
    
    <div class="d-flex align-items-center p-3 rounded-4 shadow-sm" 
         style="background: rgba(255, 255, 255, 0.05); border: 1px solid rgba(255, 255, 255, 0.1);">
        
        <div class="flex-shrink-0">
            <img src="img/user.png" 
                 alt="User" 
                 class="rounded-circle border border-2 border-primary" 
                 width="45" height="45">
        </div>

        <div class="flex-grow-1 ms-3">
            <h6 class="mb-1 fw-bold text-white text-uppercase" style="font-size: 0.9rem; letter-spacing: 0.5px;">
                <?php echo $user; ?>
            </h6>
            <span class="badge bg-success bg-opacity-25 text-success border border-success border-opacity-25 rounded-pill">
                $ <?php echo number_format($userData['balance'], 4); ?>
            </span>
        </div>
        
    </div>
    </div>  
    
    
    
    
    
    
    
    
    
    <nav>
        <a href="index.php" class="nav-item active"><i class="fas fa-home"></i> Dashboard</a>
        <a href="buy.php" class="nav-item"><i class="fas fa-cart-plus"></i> Order Now</a>
        <a href="history.php" class="nav-item"><i class="fas fa-history"></i> Order History</a>
        <a href="add_funds.php" class="nav-item"><i class="fas fa-wallet"></i> Add Money</a>
        
        <div class="sidebar-divider"></div>
        
        <a href="service.html" class="nav-item"><i class="fas fa-list"></i> Services</a>
        <a href="API.php" class="nav-item"><i class="fas fa-code"></i> API</a>
        <a href="report.php" class="nav-item"><i class="fas fa-envelope-open-text"></i> Report Ticket</a>
        <a href="https://wa.me/8801811925142" class="nav-item"><i class="fas fa-headset"></i> Support</a>
<a href="developer.html" class="nav-item developer-link">
    <div class="icon-rotator">
        <i class="fas fa-laptop-code active"></i>
        <i class="fas fa-terminal"></i>
        <i class="fas fa-bug"></i>
        <i class="fas fa-database"></i>
        <i class="fas fa-server"></i>
        <i class="fas fa-cogs"></i>
        <i class="fas fa-user-cog"></i>
        <i class="fas fa-tools"></i>
        <i class="fas fa-project-diagram"></i>
        <i class="fas fa-network-wired"></i>
        <i class="fas fa-shield-alt"></i>
    </div>
    <span class="dev-text">The Developer</span>
    <i class="fas fa-code ms-auto pulse-code"></i>
</a>
        
        <div class="sidebar-divider"></div>

        <a href="logout.php" class="nav-item text-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
    </nav>
</div>

<div class="main-content">
    
    <div class="top-bar">
        <div class="d-flex align-items-center">
            <div class="menu-btn me-3" onclick="toggleMenu()">
                <i class="fas fa-bars"></i>
            </div>
            <h5 class="m-0 fw-bold text-dark" style="font-size: 18px;">Dashboard</h5>
        </div>
        <div>
            <img src="img/user.png" class="rounded-circle" width="35">
        </div>
        
    </div>
<hr>

    
    
    
    
    
    
    
    
    
    <div class="row g-2 g-md-3 mb-4">
    <div class="col-6 col-md-3">
        <div class="stat-card-premium">
            <div class="stat-inner">
                <div class="stat-icon-mini bg-indigo-soft">
                    <i class="fas fa-user-shield"></i>
                </div>
                <div class="stat-data">
                    <span class="stat-tag">Username</span>
                    <h6 class="stat-main-text"><?php echo htmlspecialchars($user); ?></h6>
                </div>
            </div>
            <div class="stat-progress-bar bg-indigo"></div>
        </div>
    </div>

    <div class="col-6 col-md-3">
        <div class="stat-card-premium">
            <div class="stat-inner">
                <div class="stat-icon-mini bg-emerald-soft">
                    <i class="fas fa-wallet"></i>
                </div>
                <div class="stat-data">
                    <span class="stat-tag">Balance</span>
                    <h6 class="stat-main-text">$<?php echo number_format($userData['balance'], 2); ?></h6>
                </div>
            </div>
            <div class="stat-progress-bar bg-emerald"></div>
        </div>
    </div>

    <div class="col-6 col-md-3">
        <div class="stat-card-premium">
            <div class="stat-inner">
                <div class="stat-icon-mini bg-amber-soft">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="stat-data">
                    <span class="stat-tag">Total Orders</span>
                    <h6 class="stat-main-text"><?php echo number_format($total_orders); ?></h6>
                </div>
            </div>
            <div class="stat-progress-bar bg-amber"></div>
        </div>
    </div>

    <div class="col-6 col-md-3">
        <div class="stat-card-premium">
            <div class="stat-inner">
                <div class="stat-icon-mini bg-rose-soft">
                    <i class="fas fa-gift"></i>
                </div>
                <div style="padding-left: 5px !important" class="stat-data">
                    <span class="stat-tag">Referral</span>
                    <span style="padding-left: 5px !important" class=" mini-ref-badge" onclick="copyReferral()" style="cursor: pointer;">
                        <?php echo $referral_code; ?> <i class="fas fa-copy ms-1" style="font-size: 8px;"></i>
                    </span>
                </div>
            </div>
            <div class="stat-progress-bar bg-rose"></div>
        </div>
    </div>
</div>
<hr>
    
    <div class="dashboard-box" style="overflow: hidden;">

    <iframe 

        src="buy.php" 

        style="width: 100%; height: 100vh; border: none; outline: none;" 

        title="Buy Service"

        loading="lazy">

    </iframe>
        
      <div class="dashboard-box">


</div>  

</div>
    
    <hr>
    <br> <br>
<div class="announcement-wrapper shadow-sm mb-4">
    <div class="announcement-header">
        <div class="d-flex align-items-center">
            <div class="pulse-icon-box">
                <i class="fas fa-bullhorn"></i>
            </div>
            <div class="ms-2">
                <h6 class="ann-title">ANNOUNCEMENTS</h6>
                <div class="ann-status">
                    <span class="dot-live"></span> SYSTEM LIVE
                </div>
            </div>
        </div>
        <i class="fas fa-ellipsis-h text-muted" style="font-size: 10px;"></i>
    </div>

    <div class="announcement-body">
        <div class="info-glass-box">
            <div class="d-flex">
                <i class="fas fa-bolt text-warning mt-1 me-2" style="font-size: 10px;"></i>
                <p class="ann-text">
                    <?php echo nl2br(htmlspecialchars($notification_text)); ?>
                </p>
            </div>
        </div>
    </div>

    <div class="announcement-footer">
        <i class="fas fa-sync-alt fa-spin me-1"></i> Auto-refresh enabled
    </div>
</div>
    
    
    
    <style>
:root {
    --indigo: #4361ee;
    --emerald: #10b981;
    --amber: #f59e0b;
    --rose: #f43f5e;
}

/* Stat Card Premium Design */
.stat-card-premium {
    background: #ffffff;
    border-radius: 12px;
    position: relative;
    overflow: hidden;
    border: 1px solid #f0f2f5;
    transition: 0.3s;
    height: 100%;
}

.stat-card-premium:hover {
    transform: translateY(-3px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

.stat-inner {
    padding: 10px;
    display: flex;
    align-items: center;
}

.stat-icon-mini {
    width: 30px;
    height: 30px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    flex-shrink: 0;
}

.stat-tag {
    display: block;
    font-size: 9px;
    font-weight: 700;
    color: #8e9aaf;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    line-height: 1; padding-left: 5px !important;
    margin-bottom: 2px;
}

.stat-main-text {
    margin: 0; padding-left: 5px !important;

    font-size: 12px;
    font-weight: 800;
    color: #1a1c2e;
    line-height: 1.2;
}

.stat-progress-bar {
    height: 2px;
    width: 100%;
    opacity: 0.3;
}

/* Announcement Box Style */
.announcement-wrapper {
    background: #fff;
    border-radius: 15px;
    border-left: 4px solid var(--indigo);
    overflow: hidden;
}

.announcement-header {
    padding: 8px 12px;
    background: rgba(67, 97, 238, 0.02);
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #f8f9fa;
}

.ann-title {
    font-size: 10px;
    font-weight: 900;
    margin: 0;
    letter-spacing: 1px;
    color: #2d3436;
}

.ann-status {
    font-size: 8px;
    font-weight: 700;
    color: #10b981;
    display: flex;
    align-items: center;
}

.dot-live {
    height: 5px;
    width: 5px;
    background-color: #10b981;
    border-radius: 50%;
    display: inline-block;
    margin-right: 4px;
    box-shadow: 0 0 5px #10b981;
}

.info-glass-box {
    background: #fcfdfe;
    padding: 10px;
    margin: 10px;
    border-radius: 10px;
    border: 1px solid #f1f3f5;
}

.ann-text {
    font-size: 11px;
    font-weight: 500;
    color: #4a4e69;
    line-height: 1.5;
    margin: 0;
}

.announcement-footer {
    padding: 5px;
    font-size: 8px;
    text-align: center;
    background: #f8f9fa;
    color: #adb5bd;
    font-weight: 600;
}

.mini-ref-badge {
    background: linear-gradient(90deg, #4361ee, #4facfe);
    color: #fff;
    font-size: 9px;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 4px;
    display: inline-flex;
    align-items: center;
}

.pulse-icon-box {
    background: #4361ee;
    color: #fff;
    width: 24px;
    height: 24px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 10px;
}

/* Background Helpers */
.bg-indigo-soft { background: rgba(67, 97, 238, 0.1); color: var(--indigo); }
.bg-emerald-soft { background: rgba(16, 185, 129, 0.1); color: var(--emerald); }
.bg-amber-soft { background: rgba(245, 158, 11, 0.1); color: var(--amber); }
.bg-rose-soft { background: rgba(244, 63, 94, 0.1); color: var(--rose); }

.bg-indigo { background: var(--indigo); }
.bg-emerald { background: var(--emerald); }
.bg-amber { background: var(--amber); }
.bg-rose { background: var(--rose); }

@media (max-width: 576px) {
    .stat-main-text { font-size: 11px; }
    .stat-inner { padding: 8px; }
    .stat-icon-mini { width: 26px; height: 26px; font-size: 10px; }
}
</style>
    
    <style>
/* কম্প্যাক্ট কার্ড স্টাইল */
.stat-card-compact {
    background: #ffffff;
    border-radius: 12px;
    padding: 12px;
    display: flex;
    align-items: center;
    border: 1px solid #f1f4f9;
    box-shadow: 0 2px 8px rgba(0,0,0,0.03);
    height: 100%;
}

.stat-icon-small {
    width: 35px;
    height: 35px;
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 14px;
    margin-right: 10px;
    flex-shrink: 0;
}

/* আইকন ব্যাকগ্রাউন্ড কালার */
.bg-indigo-soft { background: rgba(67, 97, 238, 0.1); color: #4361ee; }
.bg-emerald-soft { background: rgba(16, 185, 129, 0.1); color: #10b981; }
.bg-amber-soft { background: rgba(245, 158, 11, 0.1); color: #f59e0b; }
.bg-rose-soft { background: rgba(244, 63, 94, 0.1); color: #f43f5e; }

.stat-info-compact {
    min-width: 0; /* text-truncate কাজ করার জন্য */
}

.stat-label {
    display: block;
    font-size: 10px;
    text-transform: uppercase;
    font-weight: 700;
    color: #64748b;
    margin-bottom: 2px;
    letter-spacing: 0.3px;
}

.stat-value {
    margin: 0;
    font-size: 13px;
    font-weight: 700;
    color: #1e293b;
}

/* রেফারেল ব্যাজ স্টাইল */
.ref-badge {
    background: linear-gradient(45deg, #4361ee, #4facfe);
    color: white;
    padding: 2px 8px;
    border-radius: 5px;
    font-size: 11px;
    font-weight: 600;
    box-shadow: 0 2px 4px rgba(67, 97, 238, 0.2);
}

/* মোবাইল রেসপন্সিভনেস */
@media (max-width: 576px) {
    .stat-card-compact {
        padding: 10px 8px;
    }
    .stat-icon-small {
        width: 30px;
        height: 30px;
        font-size: 12px;
        margin-right: 6px;
    }
    .stat-label { font-size: 9px; }
    .stat-value { font-size: 11px; }
    .ref-badge { font-size: 10px; padding: 1px 6px; }
}
</style>
    
    <style>

.developer-link {

    display: flex;

    align-items: center;

    text-decoration: none;

    background: rgba(255, 255, 255, 0.05);

    padding: 10px 15px;

    border-radius: 12px;

    border: 1px solid rgba(255, 255, 255, 0.1);

    transition: 0.3s;

    overflow: hidden;

}

.developer-link:hover {

    background: rgba(67, 97, 238, 0.1);

    border-color: #4361ee;

}

/* আইকন রোটেশন বক্স */

.icon-rotator {

    width: 25px;

    height: 25px;

    position: relative;

    margin-right: 12px;

    display: flex;

    justify-content: center;

    align-items: center;

}

.icon-rotator i {

    position: absolute;

    font-size: 16px;

    color: #4361ee;

    opacity: 0;

    transform: translateY(10px) scale(0.5);

    transition: all 0.5s cubic-bezier(0.68, -0.55, 0.265, 1.55);

}

/* অ্যাক্টিভ আইকন স্টাইল */

.icon-rotator i.active {

    opacity: 1;

    transform: translateY(0) scale(1);

}

.dev-text {

    font-size: 14px;

    font-weight: 600;

    color: #e0e6ed;

}

/* কোড আইকনের জন্য পালস এনিমেশন */

.pulse-code {

    font-size: 12px;

    color: #28c76f;

    animation: codePulse 1.5s infinite;

}

@keyframes codePulse {

    0% { transform: scale(1); opacity: 1; }

    50% { transform: scale(1.2); opacity: 0.7; }

    100% { transform: scale(1); opacity: 1; }

}

</style>
    
    <script>

function copyReferral() {

    const code = "<?php echo $referral_code; ?>";

    navigator.clipboard.writeText(code).then(() => {

        alert("Referral code copied: " + code);

    });

}

</script>
   
<script>
    function toggleMenu() {
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('overlay');
        
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    }
</script>
    
    
    
    
    <script>

document.addEventListener("DOMContentLoaded", function() {

    const icons = document.querySelectorAll(".icon-rotator i");

    let currentIndex = 0;

    setInterval(() => {

        // বর্তমান আইকন থেকে active ক্লাস সরিয়ে নিন

        icons[currentIndex].classList.remove("active");

        // পরবর্তী ইনডেক্স সেট করুন

        currentIndex = (currentIndex + 1) % icons.length;

        // নতুন আইকনে active ক্লাস যোগ করুন

        icons[currentIndex].classList.add("active");

    }, 1500); // প্রতি ১.৫ সেকেন্ড পর পর পরিবর্তন হবে

});

</script>

</body>
</html>