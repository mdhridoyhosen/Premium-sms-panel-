<?php
$servername = "sql303.infinityfree.com";
$username = "if0_39944885";
$password = "AYOaNvQ2VS";
$dbname = "if0_39944885_ftcsmm";

// কানেকশন তৈরি করা
$conn = new mysqli($servername, $username, $password, $dbname);

// কানেকশন চেক করা
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>