<?php
session_start();
include 'db.php';

// ১. লগইন চেক
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
    exit();
}

$user = $_SESSION['username'];
$userData = null;

// ইউজার ডাটা আনা
$user_sql = "SELECT * FROM users WHERE username = '$user'";
$user_res = $conn->query($user_sql);

if($user_res->num_rows > 0){
    $userData = $user_res->fetch_assoc();
} else {
    session_destroy();
    header("Location: index.php");
    exit();
}

// ========================================================
// ⚙️ PAYMENT DETAILS (ফিক্সড ডাটা - ইউজার এডিট করতে পারবে না)
// ========================================================
$bkash_number   = "01883731970"; 
$nagad_number   = "01883731970"; 
$rocket_number  = "017018596718"; 
$upay_number    = "01883731970"; // Upay Number
$cellfin_number = "01883731970"; // Cellfin Number
$tap_number     = "01883731970"; // Tap Number

$binance_uid    = "569128889";   
$binance_pay_id = "saymonboss24@gmail.com"; // Pay ID or Email

$paypal_email   = "rhsimon970@gmail.com";   
$payoneer_email = "saymonboss24@gmail.com"; 
$perfect_money  = "U12345678"; // Example PM ID
$payeer_id      = "P12345678"; // Example Payeer ID

// ========================================================
// ৪. ফর্ম সাবমিশন এবং ডাটাবেস লজিক
$success_msg = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $trx_id = mysqli_real_escape_string($conn, $_POST['trx_id']);
    
    // ডাটাবেসে সেভ (Pending)
    $insert_sql = "INSERT INTO deposits (username, method, amount, trx_id, status) VALUES ('$user', '$method', '$amount', '$trx_id', 'Pending')";
    
    if($conn->query($insert_sql) === TRUE) {
        // টেলিগ্রাম নোটিফিকেশন
        $botToken = "8091274126:AAEmZCgDXt1SbH7c4LlTmGa7hXfLuRHURBM";
        $chat_id = "-1003625741937"; 
        
        $message = "💰 **New Fund Request**\n\n";
        $message .= "👤 **User:** " . $user . "\n";
        $message .= "💳 **Method:** " . ucfirst($method) . "\n";
        $message .= "💵 **Amount:** " . $amount . "\n";
        $message .= "🆔 **TrxID:** `" . $trx_id . "`\n\n";
        $message .= "⚠️ *Check payment manually then update DB.*";

        $telegram_ip = "149.154.167.220"; 
        $url = "https://$telegram_ip/bot$botToken/sendMessage";
        
        $data = [ 'chat_id' => $chat_id, 'text' => $message, 'parse_mode' => 'Markdown' ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Host: api.telegram.org"));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
        curl_exec($ch);
        curl_close($ch);

        $success_msg = true;
    }
}

// ৫. ডিপোজিট হিস্ট্রি আনা
$history_sql = "SELECT * FROM deposits WHERE username = '$user' ORDER BY id DESC LIMIT 10";
$history_res = $conn->query($history_sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Funds - All Methods</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Rajdhani:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">

    <style>
        :root { --primary: #4361ee; --secondary: #3a0ca3; --bg-body: #f3f4f6; }
        body { font-family: 'Poppins', sans-serif; background: var(--bg-body); overflow-x: hidden; }

        /* Navbar & Capsule */
        .navbar-custom { padding: 15px 25px; background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(15px); border-bottom: 1px solid rgba(0,0,0,0.05); position: sticky; top: 0; z-index: 1000; }
        .brand-text { font-family: 'Rajdhani', sans-serif; font-weight: 700; font-size: 22px; letter-spacing: 1px; }
        .user-capsule { display: flex; align-items: center; background: #fff; padding: 5px 5px 5px 20px; border-radius: 50px; border: 1px solid #e0e6ed; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .balance-box { margin-right: 15px; color: #10b981; font-weight: 600; display: flex; align-items: center; gap: 5px; }
        .currency-symbol { background: rgba(16, 185, 129, 0.1); width: 24px; height: 24px; display: flex; align-items: center; justify-content: center; border-radius: 50%; font-size: 12px; }
        .avatar-box img { width: 40px; height: 40px; border-radius: 50%; border: 2px solid #fff; }

        /* Card & Instruction */
        .card-box { background: #fff; border-radius: 16px; padding: 35px; box-shadow: 0 10px 30px rgba(0,0,0,0.04); border: 1px solid #fff; margin-bottom: 30px; }
        .instruction-box { background: #f8f9fa; border: 1px dashed #ced4da; padding: 20px; border-radius: 10px; margin-bottom: 20px; display: none; }
        .qr-img { max-width: 180px; border: 2px solid #eee; border-radius: 10px; padding: 5px; background: white; }
        .copy-btn { cursor: pointer; color: var(--primary); font-weight: bold; }
        .copy-btn:hover { text-decoration: underline; }

        /* Table */
        .table-custom { width: 100%; border-collapse: separate; border-spacing: 0 10px; }
        .table-custom thead th { border: none; font-weight: 600; color: #888; font-size: 12px; padding: 10px; }
        .table-custom tbody tr { background: #fff; box-shadow: 0 2px 10px rgba(0,0,0,0.02); }
        .table-custom td { padding: 15px; vertical-align: middle; font-size: 14px; border: none; }
        .badge-pending { background: rgba(255, 193, 7, 0.15); color: #ffab00; padding: 5px 12px; border-radius: 30px; font-weight: 600; font-size: 11px; }
        .badge-success { background: rgba(16, 185, 129, 0.15); color: #10b981; padding: 5px 12px; border-radius: 30px; font-weight: 600; font-size: 11px; }

        .btn-submit { background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: white; border: none; padding: 14px; border-radius: 10px; font-weight: 600; width: 100%; transition: 0.3s; }
        .btn-submit:hover { transform: translateY(-2px); box-shadow: 0 5px 20px rgba(67, 97, 238, 0.4); }

        /* Number Display */
        .number-display {
            font-size: 20px; font-weight: 700; color: #333; letter-spacing: 1px;
            background: #fff; padding: 10px; border-radius: 8px; border: 1px solid #ddd;
            display: inline-block; margin: 10px 0;
        }

        /* WhatsApp Float */
        .ftc-whatsapp-float { position: fixed; width: 60px; height: 60px; bottom: 30px; right: 30px; background-color: #25d366; color: #FFF; border-radius: 50%; text-align: center; font-size: 30px; box-shadow: 2px 2px 10px rgba(0,0,0,0.2); z-index: 9999; display: flex; align-items: center; justify-content: center; }
    </style>
</head>

<body>

<nav class="navbar-custom">
    <div class="container-fluid d-flex justify-content-between align-items-center">
        <div class="brand-text"><i class="fas fa-bolt text-warning">money </i></div>
        <div class="user-capsule">
            <div class="balance-box"><span class="currency-symbol">$</span><span><?php echo number_format($userData['balance'], 4); ?></span></div>
            <div class="avatar-box ms-3"><img src="https://ui-avatars.com/api/?name=<?php echo $user; ?>" alt="User"></div>
        </div>
    </div>
</nav>

<div class="container py-5">
    <div class="row justify-content-center">
        
        <div class="col-lg-7 mb-4">
            <div class="card-box h-100" data-aos="fade-up">
                <div class="text-center mb-4">
                    <h3 class="fw-bold text-dark"><i class="fas fa-wallet text-primary me-2"></i> Add Funds</h3>
                    <p class="text-muted small">Select a payment method securely</p>
                </div>

                <form action="" method="POST">
                    <div class="mb-4">
                        <label class="form-label fw-bold small text-muted">SELECT METHOD</label>
                        <select class="form-select form-select-lg shadow-none" name="payment_method" id="paymentMethod" required>
                            <option value="" selected disabled>-- Select Payment Method --</option>
                            <optgroup label="🇧🇩 Bangladesh (Mobile Banking)">
                                <option value="bkash">bKash (Personal)</option>
                                <option value="nagad">Nagad (Personal)</option>
                                <option value="rocket">Rocket (Personal)</option>
                                <option value="upay">Upay (Personal)</option>
                                <option value="cellfin">Cellfin</option>
                                <option value="tap">Tap</option>
                            </optgroup>
                            <optgroup label="🌐 Crypto Currency">
                                <option value="binance">Binance Pay (ID/UID)</option>
                            </optgroup>
                            <optgroup label="🌎 International">
                                <option value="paypal">PayPal</option>
                                <option value="payoneer">Payoneer</option>
                                <option value="perfect_money">Perfect Money</option>
                                <option value="payeer">Payeer</option>
                            </optgroup>
                        </select>
                    </div>

                    <div id="bd-section" class="instruction-box text-center">
                        <img id="method-logo" src="" style="height: 50px; margin-bottom: 10px; display: none;">
                        <h6 class="fw-bold"><i class="fas fa-info-circle text-info"></i> Send Money (Personal)</h6>
                        
                        <div class="d-flex justify-content-center align-items-center gap-2">
                            <span class="number-display" id="bd-number-display">Select Method</span>
                            <button type="button" class="btn btn-outline-primary btn-sm" onclick="copyNumber()"><i class="fas fa-copy"></i></button>
                        </div>
                        <p class="small text-muted mt-2">Reference: <strong class="text-dark"><?php echo $user; ?></strong></p>
                    </div>

                    <div id="binance-section" class="instruction-box text-center">
                        <h6 class="fw-bold mb-3"><i class="fab fa-bitcoin text-warning"></i> Binance Pay</h6>
                        <img alt="QR Code" src="img/binace.jpg" class="qr-img mb-3">
                        
                        <div class="mb-2">
                            <small class="text-muted">Binance UID:</small> <br>
                            <strong class="h5"><?php echo $binance_uid; ?></strong> 
                            <i class="fas fa-copy copy-btn ms-2" onclick="copyToClipboard('<?php echo $binance_uid; ?>')"></i>
                        </div>
                        <div class="mb-2">
                            <small class="text-muted">Pay ID/Email:</small> <br>
                            <strong><?php echo $binance_pay_id; ?></strong>
                            <i class="fas fa-copy copy-btn ms-2" onclick="copyToClipboard('<?php echo $binance_pay_id; ?>')"></i>
                        </div>
                    </div>

                    <div id="global-section" class="instruction-box text-center">
                        <h6 class="fw-bold mb-3"><i class="fas fa-globe text-primary"></i> International Payment</h6>
                        <p class="small mb-2">Send payment to:</p>
                        
                        <div class="alert alert-light border fw-bold text-dark d-flex justify-content-between align-items-center">
                            <span id="global-address">Select Method</span>
                            <i class="fas fa-copy copy-btn" onclick="copyGlobal()"></i>
                        </div>
                        <small class="text-muted">Send as "Friends & Family" to avoid fees.</small>
                    </div>

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-muted">AMOUNT</label>
                            <input type="number" name="amount" class="form-control" placeholder="0.00" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-bold small text-muted">TRANSACTION ID (TrxID)</label>
                            <input type="text" name="trx_id" class="form-control" placeholder="X8SD..." required>
                        </div>
                    </div>

                    <div class="mt-4">
                        <button type="submit" class="btn-submit">
                            <i class="fas fa-paper-plane me-2"></i> Submit Request
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card-box h-100" data-aos="fade-up" data-aos-delay="100">
                <h5 class="fw-bold text-dark mb-4"><i class="fas fa-history text-secondary me-2"></i> Recent Deposits</h5>
                <div class="table-responsive">
                    <table class="table-custom">
                        <thead><tr><th>Via</th><th>Amount</th><th>Status</th></tr></thead>
                        <tbody>
                            <?php 
                            if($history_res->num_rows > 0) {
                                while($row = $history_res->fetch_assoc()) {
                                    $status_badge = '<span class="badge-pending">Checking</span>';
                                    if(strtolower($row['status']) == 'success') $status_badge = '<span class="badge-success">Success</span>';
                                    
                                    echo "<tr>
                                        <td>".ucfirst($row['method'])."</td>
                                        <td class='fw-bold'>$".$row['amount']."</td>
                                        <td>{$status_badge}</td>
                                    </tr>";
                                }
                            } else {
                                echo "<tr><td colspan='3' class='text-center text-muted'>No history found.</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<a href="https://wa.me/8801811925142" class="ftc-whatsapp-float" target="_blank"><i class="fab fa-whatsapp"></i></a>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>

<script>
    AOS.init({ once: true });

    // Payment Data Object (Hardcoded Security)
    const paymentData = {
        bkash:   "<?php echo $bkash_number; ?>",
        nagad:   "<?php echo $nagad_number; ?>",
        rocket:  "<?php echo $rocket_number; ?>",
        upay:    "<?php echo $upay_number; ?>",
        cellfin: "<?php echo $cellfin_number; ?>",
        tap:     "<?php echo $tap_number; ?>",
        
        // Global
        paypal:        "<?php echo $paypal_email; ?>",
        payoneer:      "<?php echo $payoneer_email; ?>",
        perfect_money: "<?php echo $perfect_money; ?>",
        payeer:        "<?php echo $payeer_id; ?>"
    };

    // Logos (Optional - Add your image paths here if needed)
    const logos = {
        bkash: "img/bkash.png", nagad: "img/nagad.png", rocket: "img/rocket.png"
    };

    const methodSelect = document.getElementById('paymentMethod');
    const sections = {
        bd: document.getElementById('bd-section'),
        binance: document.getElementById('binance-section'),
        global: document.getElementById('global-section')
    };
    
    const bdNumber = document.getElementById('bd-number-display');
    const globalAddr = document.getElementById('global-address');

    methodSelect.addEventListener('change', function() {
        const val = this.value;
        
        // Hide all
        Object.values(sections).forEach(sec => sec.style.display = 'none');

        // Logic
        if(['bkash','nagad','rocket','upay','cellfin','tap'].includes(val)) {
            sections.bd.style.display = 'block';
            bdNumber.innerText = paymentData[val];
        } 
        else if (val === 'binance') {
            sections.binance.style.display = 'block';
        }
        else if (['paypal','payoneer','perfect_money','payeer'].includes(val)) {
            sections.global.style.display = 'block';
            globalAddr.innerText = paymentData[val];
        }
    });

    // Copy Functions
    function copyToClipboard(text) {
        navigator.clipboard.writeText(text);
        Swal.fire({toast: true, position: 'top-end', icon: 'success', title: 'Copied!', showConfirmButton: false, timer: 1500});
    }
    function copyNumber() { copyToClipboard(bdNumber.innerText); }
    function copyGlobal() { copyToClipboard(globalAddr.innerText); }

    <?php if($success_msg): ?>
    Swal.fire({ title: 'Submitted!', text: 'Deposit request received. Wait for approval.', icon: 'success', confirmButtonColor: '#4361ee'});
    <?php endif; ?>
</script>

</body>
</html>